import React, { useEffect, useState } from 'react';

import { Link, useNavigate } from 'react-router-dom';
import styles from './PasswordRecovery.module.css'
import axios from 'axios';
import { ThemeConsumer } from 'react-bootstrap/esm/ThemeProvider';


const PasswordRecovery = () => {
let navigate=useNavigate();
const [err,setErr]=useState("");

function Verify(e){
  e.preventDefault();
  axios.post(`http://localhost:5297/api/User/VerifyUserPasswordRecovery/${email}/${mobile}`)
  .then((response)=>{if(response.data==true){
    sessionStorage.setItem("precover",true);
    navigate("/changepass");
    

  }
  else{
        setErr("Invalid credentials....")
  }
})
  


  .catch((e)=>console.log(e))
}

  const [email,setEmail] = useState("")

  const[mobile,setmobile]=useState("");
  return (
    <>
      
      <div className={styles.bgimg}>
        <div className={styles.content}>
        <button className={styles.homebutton} style={{float: "left"}}> Back</button><br/><br/><br/>
          <header>Enter Details</header>
          <form onSubmit={Verify}>
            <div className={styles.field}>
              <span className="fa fa-phone"></span>
              <input
                type="text"
                required
                placeholder="Enter Mobile No"
                onChange={(e)=>setmobile(e.target.value)}
              />
            </div>
            <div className={styles.field}>
              <span className="fa fa-envelope"></span>
              <input
                type="email"
                required
                placeholder="Enter Email Id"
                onChange={(e)=>setEmail(e.target.value)}
              />
            </div>
          
            <div className="error" style={{color:"red"}}>{err}</div>
            <div className="field">
              <input type="submit"  value="SUBMIT" />
            </div>
          </form>
          <div className="login" style={{color:"white"}}>Remember your password? <a href="#">Login</a></div>
        </div>
      </div>
    </>
  );
}

export default PasswordRecovery;
