import React, { useEffect, useState } from 'react';
import { useNavigate,Link } from 'react-router-dom';
import styles from "./LoginUser.module.css";
import axios from "axios";
import RegistrationPage from './Register';
import { hover } from '@testing-library/user-event/dist/hover';

  //const navigate = useNavigate();


const LoginUser = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState({ username: "", password: "" });
  const [err, setErr] = useState("");

  sessionStorage.setItem("precover",false);

  useEffect(()=>{},[]);
  const Validate = (e) => {
    e.preventDefault();
    // Check if username and password are filled out
    if (!user.username || !user.password) {
      setErr("Please enter both username and password");
      return;
    }
    e.preventDefault();
    axios
      .post("http://localhost:5297/api/Login/Login", user)
      .then((response) => {
        console.log(response.data);
        let validUser = response.data;
        if (validUser != null) {
          //set username in sessionstorage
          sessionStorage.setItem("username", validUser.userName);
          sessionStorage.setItem("token", validUser.token);
          // sessionStorage.setItem("userid", validUser.);
          if (validUser.role === "Admin") {
            navigate("/admin-dashboard/");
          } else if (validUser.role === "Student") {
            navigate("/student-dashboard/");
          } else if (validUser.role === "Teacher") {
            navigate("/teacher-dashboard/");
          } else if(validUser.role===null){
            setErr("Invalid User Credentials");
          }
        } else {
          setErr("Invalid User Credentials");
        }
      })
      .catch((err) => console.log(err));
  };



  return (
    <>
      <div className={styles.bgimg}>
        <div className={styles.content}>
        <button onClick={()=>{navigate("/")}} className={styles.homebutton} style={{float: "left"}}> Back</button><br/><br/><br/>
          <header>Login Form</header>
          <form onSubmit={Validate}>
     
            <div className={styles.field}>
              <span class="fa fa-user"></span>
              <input
                type="text"
                placeholder='Username'
                value={user.email}
                onChange={(e) =>
                  setUser((prevstate) => ({
                    ...prevstate,
                    username: e.target.value,
                  }))
                }
              />
            </div>
            <br/> 
            <div className={styles.field}>
              <span class="fa fa-lock"></span>
              <input
                type="password"
                placeholder='Password'
                className='pass-key'
                value={user.password}
                onChange={(e) =>
                  setUser((prevstate) => ({
                    ...prevstate,
                    password: e.target.value,
                  }))
                }
              />
              <span class="show"></span>
            </div>

            <div className={styles.field}>
              <input type="submit" value="LOGIN" />
            </div>
          </form>
          <div style={{color:'red'}}>{err}</div> {/* Display error message */}
          <div class="pass">
              <a style={{color:"white"}} onClick={()=>navigate("/forgotpass")}>Forgot Password?</a>
            </div>
          <div className={styles.signup }>Don't have account?
          <Link to="/registerpage">Register</Link>
          </div>
        </div>
      </div>
    </>
  );
}

export default LoginUser;








// <div className="container">
//       <form onSubmit={Validate}>
//         <table className="table table-bordered">
//           <tr>
//             <td>UserName</td>
//             <td>
              
//             </td>
//           </tr>
//           <tr>
//             <td>Password</td>
//             <td>
              
//             </td>
//           </tr>
//           <tr>
//             <td colSpan={2}>
//               <button type="submit">Login</button>
//             </td>
//           </tr>
//           <tr>
//             <td colSpan={2}>
//               <span className="text-warning">{err}</span>
//             </td>
//           </tr>
//         </table>
//       </form>
//     </div>