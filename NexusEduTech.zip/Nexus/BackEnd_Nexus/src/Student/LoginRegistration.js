import { useEffect } from "react";
import AboutCard from "../components/about/AboutCard";
import HAbout from "../components/home/HAbout";
import Hblog from "../components/home/Hblog";
import Hero from "../components/home/hero/Hero";

function HomeRegistraion() {

    useEffect(()=>{
        sessionStorage.clear();
    },[])
    return ( 
    <>
        <Hero />
        {/* <AboutCard /> */}
        <HAbout />
        <Hblog />
    </> );
}

export default HomeRegistraion;