import React, { useEffect, useState } from 'react';
import styles from "./RegistrationPage.module.css";
import { Link, Navigate, useNavigate } from 'react-router-dom';
import axios from 'axios';
import "../App.css";

const RegistrationPage = () => {
  let [userName,setUsername]=useState("")
  let [enPassword,setPassword]=useState("") 
  let [rollNO,setRollno]=useState("") 
  let [firstName,setFname]=useState("") 
  let [lastName,setLname]=useState("") 
  let [dob,setDOB]=useState("") 
  let [gender,setGender]=useState("Male") 
  let [email,setEmail]=useState("") 
  let [mobileNum,setMobile]=useState("") 
  let [role,setRole]=useState("") 
  let [userId,setuserID]=useState("") 
  let [classId,setClassId]=useState("") 
  let [subjectID,setSubjectId]=useState("")
  let [cPassword,setCPassword]=useState("")

  const [user, setUser] = useState({ 
    
      userId: userId,
      userName: userName,
      enPassword: enPassword,
      mobile:mobileNum,
      email: email,
      role: role
    
  });

  const [StudentReg, setStudent] = useState({
    studentId: userId,
    firstName: firstName,
    lastName: lastName,
    rollNO: rollNO,
    dob: dob,
    gender: gender,
    email: email,
    mobileNum: mobileNum,
    classId: classId
   
  });
  const [TeacherReg, setTeacher] = useState({
    teacherId: userId,
    firstName: firstName,
    lastName: lastName,
    email:email,
    dob: dob,
    gender: gender,
    subjId: subjectID,
    mobileNum: mobileNum
  });

  const navigate = useNavigate();
  const [err, setErr] = useState("");

  const handleRegistration = (e) => {
    //e.preventDefault();
    //Check if all required fields are filled out
    // if (!userName || !enPassword || !cPassword || !email|| !mobileNum|| !userId){ 
    //   setErr("Please fill out all required fields");
    //   return;
    // }

    // Check if passwords match
    // if (enPassword !== cPassword) {
    //   setErr("Passwords do not match");
    //   return;
    // }

// const inputValue = [];
// for(const i in user){
//   if(user[i]){
//     inputValue.push(`$(i): $(user[i])`);
//   }
  
// }
// console.log(inputValue);

    // Reset form fields
    // setUser({ 
    //   username: "", 
    //   password: "", 
    //   confirmPassword: "", 
    //   email: "", 
    //   phone: "", 
    //   userType: "", 
    //   studentID: "", 
    //   classID: "", 
    //   teacherID: "", 
    //   subjectID: "" 
    // });
    setErr("Registration successful");
  };



  //handleRegistration();
  const Validate = (e) => {
    e.preventDefault();
    
    console.log(StudentReg)
    console.log(TeacherReg)
    console.log(user)

    if(role==='Student'){

      console.log("USERID: "+userId)
    axios
      .get("http://localhost:5297/api/StudentRegistry/GetById/"+StudentReg.studentId)
      .then((response) => {
        console.log(response.data)
      
        let validUser = response.data;
        
        console.log("test:"+validUser.stRegId);

        if (validUser.stRegId != undefined) {
          console.log(user)
          console.log(StudentReg)
          axios

          .post("http://localhost:5297/api/User/ADDUser",user)

          .then(response)
          .catch((e)=>console.log(e))
          axios
          .post("http://localhost:5297/api/Student/AddStudent",StudentReg)
          .then(response)
          .catch((e)=>console.log(e))

          console.log(StudentReg)
          setErr("Successfully Registered");
          
        } else {
         // console.log("Invalid")
          setErr("Invalid User Credentials");
        }
      })
      .catch((err) => console.log(err));

    }
    else{
      console.log("USERID: "+userId)
    axios
      .get("http://localhost:5297/api/TeacherRegistry/GetById/"+TeacherReg.teacherId)
      .then((response) => {
        console.log(response.data)
        
        let validUser = response.data;
        
        console.log("test:"+validUser.tchrRegId);
        if (validUser.tchrRegId != undefined) {

          axios
          .post("http://localhost:5297/api/User/ADDUser",user)
          .then(response)
          .catch((e)=>console.log(e))

          axios
          .post("http://localhost:5297/api/Teacher/AddTeacher",TeacherReg)
          .then(response)
          .catch((e)=>console.log(e))


          console.log(TeacherReg)

          //console.log(validUser)
          setErr("Successfully Registered");
          
        } 
        
        else {
          console.log("Invalid")
          setErr("Invalid User Credentials");
        }
      })
      .catch((err) => console.log(err));
    }


    
  };

  return (
    <>
  
      <div className={styles.bgimg}>
        <div className={styles.content}>
        <button onClick={()=>{navigate("/")}} className={styles.homebutton} style={{float: "left"}}> Back</button><br/><br/><br/>
          <header>Registration Form</header>
          <form onSubmit={Validate}>
            <div className={styles.field}>
              
            <span className="fa fa-user"></span>            
              <input
                type="text"
                required
                placeholder="Enter First Name"
                
                onChange={(e) =>{ 
                  setStudent((prev)=>({
                  ...prev,
                  firstName:e.target.value
                }));
                setTeacher((prev)=>({
                  ...prev,
                  firstName:e.target.value
                }));
                }}
              />
              <br/>
              
            </div>
            <div className={styles.field}>
              <span className="fa fa-user"></span>
              <input
                type="text"
                required
                placeholder="Enter Last Name"
                
                onChange={(e) =>{ 
                  setStudent((prev)=>({
                  ...prev,
                  lastName:e.target.value
                }));
                setTeacher((prev)=>({
                  ...prev,
                  lastName:e.target.value
                }));
                }}
              />
              <br/>
            </div>
            <div className={styles.field}>
              <span className="fa fa-user"></span>
              <input
                type="text"
                required
                placeholder="Enter Username"
                
                onChange={(e) =>{ 
                  setUser((prev)=>({
                  ...prev,
                  userName:e.target.value
                }));
              
              }}
                
              />
              <br/>
            </div>
            <div className={styles.field}>
              <span className="fa fa-envelope"></span>
              <input
                type="email"
                required
                placeholder="Enter Email Id"
                
                onChange={(e) =>{ 
                  setStudent((prev)=>({
                  ...prev,
                  email:e.target.value
                }));
                setTeacher((prev)=>({
                  ...prev,
                  email:e.target.value
                }));
                  setUser((prev)=>({
                  ...prev,
                  email:e.target.value
                }));
                }}
              />
              <br/>
            </div>
            <div className={styles.field}>
              <span className="fa fa-phone"/>
              <input
                type="tel"
                required
                placeholder="Enter Mobile Number"
                pattern="[0-9]{10}"
                onChange={(e) =>{ 
                  setStudent((prev)=>({
                  ...prev,
                  mobileNum:e.target.value
                }));
                setUser((prev)=>({
                  ...prev,
                  mobileNum:e.target.value
                }));
                setTeacher((prev)=>({
                  ...prev,
                  mobileNum:e.target.value
                }));
                }}
              />
              <br/>
            </div>
            <div className={styles.field}>
              <span className="fa fa-calender"></span>
              <input pattern="\d{4}-\d{2}-\d{2}"
                type="date"
                required
                placeholder="DOB"
                
                onChange={(e) =>{ 
                  setStudent((prev)=>({
                  ...prev,
                  dob:e.target.value
                }));
                setTeacher((prev)=>({
                  ...prev,
                  dob:e.target.value
                }));
                }}
              />
            </div>
            <div className=" fa field">
              <span className="fa "></span>
              <div class="form-group">
  
  <select class="form-control" id="genderSelect" onChange={(e) =>{ 
                  setStudent((prev)=>({
                  ...prev,
                  gender:e.target.value
                }));
                setTeacher((prev)=>({
                  ...prev,
                  gender:e.target.value
                }));
                }} style={{marginBottom: "8px"}}>
                  <option>Select Gender</option>
    <option  value="Male">Male</option>
    <option value="Female">Female</option>
    <option value="Other">Other</option>
  </select>
</div>       
          </div>
            <div className={styles.field}>
              <span className="fa fa-lock"></span>
              <input
                type="password"
                className="pass-key"
                required
                placeholder="Enter Password"
                pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$" 
                title="Must contain at least one uppercase letter, one lowercase letter, one number, one special character, and be at least  8 characters long."
                onChange={(e) =>{ 
                  setUser((prev)=>({
                  ...prev,
                  enPassword:e.target.value
                }));
                }}
              />
              <span className="show"></span>
            </div>
            <div className={styles.field}>
              <span className="fa fa-lock"></span>
              <input
                type="password"
                className="pass-key"
                required
                placeholder="Confirm Password"
          
                 onChange={(e) => {if(e.target.value!=user.enPassword){setErr("passwords do not match"); }else{setErr("Passwords match")}}}
              />
              <span className="show"></span>
            </div>
          
            <div className={styles.field}>
            <span className="	fas fa-users"></span>
            <table>
              <tr>
                <td>
                <input 
                  type="radio" 
                  name="userType" 
                  value="Student" 
                  onChange={(e) =>{ 
                  setRole(e.target.value);
                  setUser((prev)=>({
                    ...prev,
                    role:e.target.value
                  }));
                  }}
                />
                </td>
                <td>
                  &nbsp; 
                <label style={{color:"red", fontWeight:"bold"}}>
                Student
              </label>

                </td>
                &nbsp;     &nbsp; 
                <td>
              
            
                <input 
                  type="radio" 
                  name="userType" 
                  value="Teacher" 
                  onChange={(e) =>{ 

                  setRole(e.target.value);
                  setUser((prev)=>({
                    ...prev,
                    role:e.target.value
                  }));
                  }}
                />
                </td>
                <td>
                &nbsp; 
                <label style={{color:"red", fontWeight:"bold"}}>
                   Teacher
              </label>
               
                </td>
              </tr>
            </table>
          
               
             
              
             
            </div>
            {role === "Student" && (
              <>
            <div className={styles.field}>
              <span className="fa fa-user"></span>
              <input
                type="text"
                required
                placeholder="Enter RollNo"
     
                onChange={(e) =>{ 
                  setStudent((prev)=>({
                  ...prev,
                  rollNO:e.target.value
                }));
                
                }}
              />
            </div>

                <div className={styles.field}>
                <span className="fas fa-user-alt"/>
                
                  <input
                    type="text"
                    placeholder="Enter Student ID"
           
                    onChange={(e) =>{ 
                      setStudent((prev)=>({
                      ...prev,
                      studentId:e.target.value
                    }));
                    setUser((prev)=>({
                      ...prev,
                      userId:e.target.value
                    }));
                    }}
                  />
                </div>
                <div className={styles.field}>
                <span className="fas fa-user-alt"></span>
                  <input
                    type="text"
                    placeholder="Enter Class ID"
          
                    onChange={(e) =>{ 
                      setStudent((prev)=>({
                      ...prev,
                      classId:e.target.value
                    }));
                    
                    }}
                  />
                </div>
              </>
            )}
            {role === "Teacher" && (
              <>
                <div className={styles.field}>
                <span className="	fas fa-user-alt"></span>
                  <input
                    type="text"
                    placeholder="Enter Teacher ID"
          
                    onChange={(e) =>{ 
                      setUser((prev)=>({
                      ...prev,
                      userId:e.target.value
                    }));
                    setTeacher((prev)=>({
                      ...prev,
                      teacherId:e.target.value
                    }));
                    }}
                  />
                </div>
                <div className={styles.field}>
                <span className='fas fa-user-alt'></span>
                  <input
                    type="text"
                    placeholder="Enter Subject ID"
                    onChange={(e) =>{ 
                    setTeacher((prev)=>({
                      ...prev,
                      subjId:e.target.value
                    }));
                    }}
                  />
                </div>
              </>
            )}
            <div className="error" style={{color:"white"}}>{err}</div>
            <div className="field">
              <input className='btn btn-primary' type="submit" value="REGISTER" />
            </div>
          </form>
          <div className="login" style={{marginTop:"5px",backgroundColor:"black",fontWeight:"bold",color:'white'}}>Already have an account? <a style={{color:"red"}}  onClick={()=>navigate("/loginpages")}>Login</a></div>

          <div className="links">

          </div>
        </div>
      </div>
    </>
  );
}

export default RegistrationPage;
