import axios from 'axios';
import React, { useEffect, useState } from 'react';
import styles from './ChangePassword.module.css'

import { Link, useNavigate } from 'react-router-dom';

const ChangePassword = () => {

  let navigate=useNavigate();


 
  
function ChangePass(){
  axios.put(`http://localhost:5297/api/User/EditPassword/${username}/${pass}`)
  .then((response)=>{console.log(response.data)})
  .catch((e)=>{console.log(e)}) 
  
  navigate('/loginpages')
  
}

const [username,setUser] = useState("")

const[pass,setPass]=useState("");

useEffect(()=>{
  if(sessionStorage.getItem("precover")==null){
    navigate("/forgotpass")

   
  }
  console.log("Status:",sessionStorage.getItem("precover"))
},[username])

  return (
    <>
      
      <div className={styles.bgimg}>
        <div className={styles.content}>
          <header>Password Recovery</header>
          <form onSubmit={ChangePass}>
          
            <div className={styles.field}>
              <span className="fa fa-lock"></span>
              <input
                type="text"
                required
                placeholder="Enter username"
                onChange={(e)=>setUser(e.target.value)}
              />
            </div>
            <div className={styles.field}>
              <span className="fa fa-lock"></span>
              <input
                type="password"
                className="pass-key"
                required
                placeholder="New Password"
                onChange={(e)=>setPass(e.target.value)}
              />
              <span className={styles.show}></span>
            </div>
            <div className={styles.error}></div>
            <div className="field">
              <input type="submit" value="RECOVER PASSWORD" />
            </div>
          </form>
      
        </div>
      </div>
    </>
  );
}

export default ChangePassword;
