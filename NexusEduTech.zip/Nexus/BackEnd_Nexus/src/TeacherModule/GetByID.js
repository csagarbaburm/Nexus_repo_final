import React, { useState,useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const GetBYIDT  = () => {
  const [teacherId, setId] = useState("");
  const [teacherDetails, setTeacherDetails] = useState(null); // State variable to store teacher details

  const [optionsTec, setTecOption] = useState([]);

  const navigate=useNavigate();
  useEffect(()=>{
    if(sessionStorage.getItem("token")==null){
        navigate('/loginpages')
    }
})
  useEffect(()=>{


    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };


    axios.get('http://localhost:5297/api/Teacher/GetAllTeachers',{headers})
    .then((result) => {
      setTecOption(result.data);
    })
    .catch((error) => {
        console.log(error);
     
    });}
  },[])


  const getById = () => {
    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };
    axios
      .get("http://localhost:5297/api/Teacher/GetTeacher/" + teacherId,{headers})
      .then((response) => {
        setTeacherDetails(response.data); // Update state with fetched teacher details
      })
      .catch((error) => console.log(error));
  }};




  return (
    <div className="container">
      <div className="col-12 col-md-6">
      

                    <select
                      aria-label="Select Teacher Id"
                      className='form-control form-control-sm' 
                      name="Teacher Id"
                      style={{marginBottom:"10px"}}
                      value={teacherId}
                      onChange={(e) => setId(e.target.value)}
                  >
                      <option key="default" value="">
                          Select  Teacher Id
                      </option>
                      {optionsTec.map((option) => (
                          <option key={option.teacherId} value={option.teacherId}>
                              {option.teacherId}
                          </option>
                      ))}
                      
                </select>
                </div>
        <button style={{margin:"10px"}} className="btn btn-primary"  onClick={getById}>Get Teacher By ID</button>
     
    
      {teacherDetails && (
        <table className="table">
          <tbody>
            <tr>
              <td>ID</td>
              <td>{teacherId}</td>
            </tr>
            <tr>
              <td>First Name</td>
              <td>{teacherDetails.firstName}</td>
            </tr>
            <tr>
              <td>Last Name</td>
              <td>{teacherDetails.lastName}</td>
            </tr>
            <tr>
              <td>Email</td>
              <td>{teacherDetails.email}</td>
            </tr>
            <tr>
              <td>Date of Birth</td>
              <td>{teacherDetails.dob}</td>
            </tr>
            <tr>
              <td>Gender</td>
              <td>{teacherDetails.gender}</td>
            </tr>
            <tr>
              <td>Subject Taught</td>
              <td>{teacherDetails.subjectTaught}</td>
            </tr>

          </tbody>
        </table>
      )}
    </div>
  );
};

export default GetBYIDT;