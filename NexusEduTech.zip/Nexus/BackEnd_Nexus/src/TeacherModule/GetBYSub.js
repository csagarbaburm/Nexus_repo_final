import React, { useState,useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const GetBySub = () => {
  const [subjectTaught, setSubjectTaught] = useState("");
  const [teacherList, setTeacherList] = useState([]); // State variable to store teacher details


  const [optionsSub, setSubOption] = useState([]);
  const navigate=useNavigate();

  useEffect(()=>{

      if(sessionStorage.getItem("token")==null){
          navigate('/loginpages')
      }
  
    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };
    axios.get('http://localhost:5297/api/Subject/GetAllSubjects',{headers})
    .then((result) => {
        setSubOption(result.data);
    })
    .catch((error) => {
        console.log(error);
     
    });
  }



    if(sessionStorage.getItem("token")==null){
        navigate('/loginpages')
    }
},[])

  const getBysub = () => {
    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };
    axios
      .get(`http://localhost:5297/api/Teacher/GetTeacherbsubject/${subjectTaught}`,{headers})
      .then((response) => {
        setTeacherList(response.data); // Update state with fetched teacher details
      })
      .catch((error) => console.log(error));
  }};

  return (
    <div className="container">
      <div className="col-12 col-md-6">
         <select
                      aria-label="Select subject"
                      className='form-control form-control-sm' 
                      name="className"
                      style={{marginBottom:"10px"}}
                      value={subjectTaught}
                      onChange={(e) => setSubjectTaught(e.target.value)}
                  >
                      <option key="default" value="">
                          Select subject
                      </option>
                      {optionsSub.map((option) => (
                          <option key={option.subId} value={option.subId}>
                              {option.subName}
                          </option>
                      ))}
                      
                  </select>
                  </div>
        <button  className="btn btn-primary" onClick={getBysub}>Get Teachers By Subject</button>
     
      {teacherList.length > 0 && (
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Date of Birth</th>
              <th>Gender</th>
              <th>Subject Taught</th>

            </tr>
          </thead>
          <tbody>
            {teacherList.map((teacher, index) => (
              <tr key={index}>
                <td>{teacher.teacherId}</td>
                <td>{teacher.firstName}</td>
                <td>{teacher.lastName}</td>
                <td>{teacher.email}</td>
                <td>{teacher.dob}</td>
                <td>{teacher.gender}</td>
                <td>{teacher.subjectTaught}</td>

              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default GetBySub;