import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import { Form } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
const CRUDd =()=>{
 
  const navigate = useNavigate();
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
 
    const [id,setId] = useState("")
    const [firstname,setfirstname] = useState("")
    const [lastName,setlastname] = useState("")
    const [email,setemail] = useState("")
    const [dob,setdob] = useState("")
    const [gender,setgender] = useState("")
    const [subjectsTaught,setsubjecttaught] = useState("")
    const [mobileNum,setMobilenum]=useState("")
    const [classId,setClass] = useState("")
 
    const [editId,seteditId] = useState("")
    const [EditmobileNum,setEditMobilenum]=useState("")
    const [editfirstname,setEditFname] = useState("")
    const [editlastName,setEditLname] = useState("")
    const [editemail,setEditEmail] = useState("")
    const [editdob,setEditDob] = useState("")
    const [editgender,setEditGender] = useState("")
    const [editclassId,setEditClass] = useState("")
    const[editSubjectTaught,seteditsubjecttaught]= useState("")

    const [optionsCls, setClsOption] = useState([]);
    const [optionsSub, setSubOption] = useState([]);
 
    const   [ data,setdata] = useState([])
 
    const [errors, setErrors] = useState({});
 
    useEffect(()=>{
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };

      axios.get('http://localhost:5297/api/Class/GetAllClass',{headers})
      .then((result) => {
          setClsOption(result.data);
      })
      .catch((error) => {
          console.log(error);
          toast.error(error)
      });
      axios.get('http://localhost:5297/api/Subject/GetAllSubjects',{headers})
      .then((result) => {
          setSubOption(result.data);
      })
      .catch((error) => {
          console.log(error);
          toast.error(error)
      });



        if(sessionStorage.getItem("token")==null){
            navigate('/loginpages')
        }
    
       getData()
    }},[])
 
    const getData =()=>{
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
      
      axios.get('http://localhost:5297/api/Teacher/GetAllTeachers',{headers})
      .then((result)=>{
        setdata(result.data)
        console.log(result.data);
      })
      .catch((error)=>{
        console.log(error);
      })
    }}
    const handleEdit =(teacherId)=>{
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
       handleShow();
      console.log(teacherId);
       axios.get(`http://localhost:5297/api/Teacher/GetTeacher/${teacherId}`,{headers})
 
       .then((result)=>{
        console.log(result);
        setEditFname(result.data.firstName)
        setEditLname(result.data.lastName)
        setEditEmail(result.data.email)
        setEditGender(result.data.gender)
        setEditDob(result.data.dob)
        seteditId(result.data.teacherId)
        seteditsubjecttaught(result.data.subjectTaught)
        setEditClass(result.data.clsid)
       })
       .catch((error)=>{
        toast.error(error)
       })
    }}
 
    const handleDelete =(teacherId)=>
    {if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };
      if(window.confirm("Are you sure to delete this employe") === true){
        axios.delete(`http://localhost:5297/api/Teacher/DeleteTeacher/${teacherId}`,{headers})
        .then((result)=>{
          if(result.status === 200)
          {
            toast.success("Deleted succesfully")
            getData();
          }})
        .catch((error)=>{
          toast.error(error)
        })}}}
 
    const handleUpdate = ()=>{
      console.log(editId);
     console.log("check");
     const url ='http://localhost:5297/api/Teacher/EditTeacher'
     const data = {
      "teacherId": editId,
      "firstName": editfirstname,
      "lastName": editlastName,
      "email": editemail,
      "dob": editdob,
      "gender": editgender,
      "subjId": editSubjectTaught,
      "mobileNum": mobileNum
    }
    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };
    console.log(data);
    axios.put(url,data,{headers})
    .then((result)=>{
      console.log("Entered into edit api");
      handleClose()
      console.log(result.data);
      getData();
      // clear();
      toast.success("Teacher has been updated")
    })
    .catch((error)=>{
      toast.error(error)
    })}}
     
    const handleSave = () => {
        const newErrors = {};
       
    const isDuplicateId = data.some(item => item.teacherId === id);
      if (isDuplicateId) {
          newErrors.teacherId = "Teacher Id  already exists";
      } else if (!id) {
          newErrors.teacherId = "Please enter Teacher Id";
      } else {
          newErrors.teacherId = "";
      }
      if (!firstname) {
          newErrors.firstname = "Teacher Name is required";
      } else {
          newErrors.firstname = "";
      }
      if (!lastName) {
        newErrors.lastName = "Teacher Name is required";
    } else {
        newErrors.lastName = "";
    }
      if (!email) {
          newErrors.email = "Email is required";
      } else {
          newErrors.email = "";
      }
      if (!dob) {
          newErrors.dob = "dob is required";
      } else {
          newErrors.dob = "";
      }
      if (!gender) {
          newErrors.gender = "gender is required";
      } else {
          newErrors.gender = "";
      }
      if (!subjectsTaught) {
        newErrors.subjectsTaught = "Subject Taught is required";
    } else {
        newErrors.subjectsTaught = "";
    }
    if (!classId) {
      newErrors.classId = "ClassId is required";
  } else {
      newErrors.classId = "";
  }
  if (!mobileNum) {
    newErrors.mobileNum = "Mobile number is required";
} else {
    newErrors.mobileNum = "";
}
 
 
  setErrors(newErrors);
     
  if (Object.values(newErrors).every(error => !error)) {
      const url = 'http://localhost:5297/api/Teacher/AddTeacher';
      const data = {
        teacherId: id,
            firstName: firstname,
            lastName: lastName,
            email: email,
             dob: dob,
             gender: gender,
              subjId: subjectsTaught,
              mobileNum: mobileNum
      };
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
      axios.post(url, data,{headers})
          .then((result) => {
              getData();
              clear();
          })
          .catch((error) => {
              console.error(error);
          });}}}
const handleIdChange = (e) => {
const inputValue = e.target.value;
setId(inputValue);
const newErrors = { ...errors };
 
if (!/^[a-zA-Z0-9]*$/.test(inputValue)) {
    newErrors.teacherId = "Teacher ID should only contain alphanumeric characters";
} else {
    newErrors.teacherId = "";
}
setErrors(newErrors);
};
 
 
const handlefNameChange = (e) => {
const inputValue = e.target.value;
setfirstname(inputValue);
const newErrors = { ...errors };
 
if (!/^[a-zA-Z]*$/.test(inputValue)) {
  newErrors.firstName ="Teacher Name should only Alphabetic characters";
} else {
  newErrors.firstName = "";
}
setErrors(newErrors);
};
 
const handleemailChange = (e) => {
const inputValue = e.target.value;
setemail(inputValue);
const newErrors = { ...errors };
 
if (!/"^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$"/.test(inputValue)) {
    newErrors.email = "Enter valid email";
} else {
    newErrors.email = "";
}
setErrors(newErrors);
};
 
const handlelNameChange = (e) => {
    const inputValue = e.target.value;
    setlastname(inputValue);
    const newErrors = { ...errors };
    if (!/^[a-zA-Z]*$/.test(inputValue)) {
      newErrors.lastName = "Teacher Name should only Alphabetic characters";
    } else {
      newErrors.lastName = "";
    }
    setErrors(newErrors);
    };
 
const handleDOBChange = (e) => {
const selectedDate = new Date(e.target.value);
const today = new Date();
const newErrors = { ...errors };
 
if (selectedDate > today) {
  newErrors.dob = "DOB should be valid date";
} else {
  newErrors.dob = "";
  setdob(e.target.value);}
setErrors(newErrors);
};
 
const handleGenderChange = (selectedGender) => {
    setgender(selectedGender);
    setErrors(prevErrors => ({ ...prevErrors, gender: '' }));
  };
 
const handleSubjectTaughtChange = (e) => {
    setsubjecttaught(e.target.value);
setErrors(prevErrors => ({ ...prevErrors, subjectTaught: '' }));
};
const handleClassIdChange = (e) => {
    setClass(e.target.value);
setErrors(prevErrors => ({ ...prevErrors, classId: '' }));
};
const handlemobnumber = (e) => {
  const inputValue = e.target.value;
  setMobilenum(inputValue);
  const newErrors = { ...errors };
 
  if (!/"^[6-9]\d{9}$"/.test(inputValue)) {
      newErrors.mobileNum = "Enter valid Mobile number";
  } else {
      newErrors.mobileNum = "";
  }
  setErrors(newErrors);
  };
 
    const clear = ()=>{
      setId('')
      setfirstname('')
      setlastname("")
      setemail('')
      setdob('')
      setgender("")
      setsubjecttaught('')
      setClass('')
      seteditId('')
      setEditFname('')
      setEditLname('')
      setEditEmail('')
      setEditGender('')
      setEditDob('')
      seteditsubjecttaught('')
    }
    return(
        <Fragment>
          <ToastContainer/>
          <Container>
            <Row>
            <Col>
 
            <input type="text" className='form-control form-control-sm' placeholder='Enter Teacher ID'
                      value={id}  onChange={(e) => handleIdChange(e)}  />
                  {errors.teacherId && <span className="text-danger">{errors.teacherId}</span>}
        </Col>
            </Row>
      <Row className='pt-2'>
      <Col>
       
      <input type="text" className='form-control form-control-sm' placeholder='Enter first name'
                      value={firstname}  onChange={(e) => handlefNameChange(e)}  />
                  {errors.firstName && <span className="text-danger">{errors.firstName}</span>}
        </Col>
       
      <Col>
      <input type="text" className='form-control form-control-sm' placeholder='Enter second name'
                      value={lastName}  onChange={(e) => handlelNameChange(e)}  />
                  {errors.lastName && <span className="text-danger">{errors.lastName}</span>}
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='email'
                      value={email}  onChange={(e) => handleemailChange(e)}  />
                  {errors.email && <span className="text-danger">{errors.email}</span>}
        </Col>
        </Row>
 
        <Row className='pt-2'>
      <Col>
       
      <input type="text" className='form-control form-control-sm' placeholder='Enter Mobile number'
                      value={mobileNum}  onChange={(e) => handlemobnumber(e)}  />
                  {errors.mobileNum && <span className="text-danger">{errors.mobileNum}</span>}
        </Col>
       
 
        </Row>
        <Row className='pt-2'>
 
         
       
        <Col>
        <input type="date" className='form-control form-control-sm ' placeholder='Enter dob '
                      value={dob}  onChange={(e) => handleDOBChange(e)}  />
                  {errors.dob && <span className="text-danger">{errors.dob}</span>}
        </Col>
       <Col>
            <select className='pt-2 form-control form-control-sm '
            aria-label="Select Gender"
            name="gender" // Corrected the name to match the expected field
            value={gender}
            onChange={(e) => handleGenderChange(e.target.value)}
            >
            <option key="default" value="">
                Select Gender
            </option>
            <option value="Male">
                Male
            </option>
            <option value="Female">
                Female
            </option>
            </select>
            </Col>
         
          {errors.gender && <span className="text-danger">{errors.gender}</span>}

          </Row>
          <div className='pt-2'>
          <Row>
          <div className='row'>
        <Col>
                  <select
                      aria-label="Select subject"
                      className='form-control form-control-sm' 
                      name="className"
                      value={subjectsTaught}
                      onChange={(e) => handleSubjectTaughtChange(e)}
                  >
                      <option key="default" value="">
                          Select subject
                      </option>
                      {optionsSub.map((option) => (
                          <option key={option.subId} value={option.subId}>
                              {option.subName}
                          </option>
                      ))}
                      
                  </select>
                  {errors.subjectTaught && <span className="text-danger">{errors.subjectTaught}</span>}
                 
        </Col>
        <Col>
                  <select 
                      aria-label="Select Class"
                      className='form-control form-control-sm' 
                      name="className"
                      value={classId}
                      onChange={(e) => handleClassIdChange(e)}
                  >
                      <option key="default" value="">
                          Select Class
                      </option>
                      {optionsCls.map((option) => (
                          <option key={option.classId} value={option.classId}>
                              {option.name}
                          </option>
                      ))}
                      
                 </select>
                  {errors.classId && <span className="text-danger">{errors.classId}</span>}
        </Col>
        </div>
        <div className='pt-2'>
      
        </div>
        </Row>
        </div>
       
        <Row className='pt-2'>
        <Col>
        <button className='btn btn-primary '   onClick={()=>handleSave()}>Add Teacher</button>
        </Col>
      </Row>
    </Container>
    <br></br>
    <div className='pt-2'>
      <Table striped bordered hover>
      <thead>
        <tr>
          <th>index</th>
          <th>TeacherId</th>
          <th>FirstName</th>
          <th>LastName</th>
          <th>Email</th>
          <th>DOB</th>
          <th>Gender</th>
          <th>SubjectTaught</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        {
          data && data.length > 0 ?
          data.map((item,index)=>{
            return (
              <tr key={index}>
              <td>{index+1}</td>
              <td>{item.teacherId}</td>
              <td>{item.firstName}</td>
              <td>{item.lastName}</td>
              <td>{item.email}</td>
              <td>{item.dob}</td>
              <td>{item.gender}</td>
              <td>{item.subjectTaught}</td>
 
             
              <td colSpan={2}>
                <button className='btn btn-primary'  onClick={()=>handleEdit(item.teacherId)} >Edit</button> &nbsp;
                <button className='btn btn-danger' onClick={()=> handleDelete(item.teacherId)}  >Delete</button>
              </td>
            </tr>
            )
          })
          :
          'Loading.......'
        }    
      </tbody>
    </Table>
    </div>
    <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modify /Update Teacher</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Row className='pt-2'>
        <Col >
        <input type="text" className='form-control' placeholder='Enter firstname'
        value={editfirstname} onChange={(e)=> setEditFname(e.target.value)} />
        </Col>
 
        <Col>
        <input type="text" className='form-control' placeholder='Enter Lastname'
        value={editlastName} onChange={(e)=> setEditLname(e.target.value)} />
        </Col>
      </Row>
      <Row>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Email'
        value={editemail} onChange={(e)=> setEditEmail(e.target.value)} />
        </Col>
      </Row>
      <Row>
        <Col>
        <input type="text" className='form-control' placeholder='Enter mobile number'
        value={mobileNum} onChange={(e)=> setMobilenum(e.target.value)} />
        </Col>
      </Row>
      <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Gender'
        value={editgender} onChange={(e)=> setEditGender(e.target.value)} />
        </Col>
        <Col>
        <input type="data" className='form-control' placeholder='Enter Dob '
        value={editdob} onChange={(e)=> setEditDob(e.target.value)} />
        </Col>
      </Row>
      <Row>
        <Col>
        <input type="text" className='form-control' placeholder='Enter SubjectTaught'
        value={editSubjectTaught} onChange={(e)=> seteditsubjecttaught(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Enter className'
        value={editclassId} onChange={(e)=> setEditClass(e.target.value)} />
        </Col>
      </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleUpdate}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
        </Fragment>
    )
};
export default CRUDd;