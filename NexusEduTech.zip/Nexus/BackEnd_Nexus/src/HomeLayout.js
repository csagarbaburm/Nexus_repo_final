import React from "react"

import Header from "./components/common/header/Header"
import Footer from "./components/common/footer/Footer"
import { Outlet } from "react-router-dom"
import Hero from "./components/home/hero/Hero"

const HomeLayout = () => {
  return (
    <>
    <Header/>
        <Hero />
        {/* <AboutCard />
        <HAbout />
        <Hblog />
    
        <Testimonal />
      
        <Hprice /> */}
        <Outlet/>
    <Footer/>
    </>
  )
}

export default HomeLayout
