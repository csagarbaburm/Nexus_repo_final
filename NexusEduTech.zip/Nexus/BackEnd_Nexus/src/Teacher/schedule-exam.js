import React from "react";

export default function ScheduleExam() {
  return <div>schedule-test</div>;
}
