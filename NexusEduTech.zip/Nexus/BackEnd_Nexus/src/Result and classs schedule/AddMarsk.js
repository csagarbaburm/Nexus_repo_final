import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
    import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import { useNavigate } from 'react-router-dom';

const AddMarks=()=>{

    let navigate=useNavigate();
    useEffect(()=>{
      if(sessionStorage.getItem("token")==null){
          navigate('/loginpages')
      }
  },[])
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
      //Edit


  const[marksId,setmarksId]=useState("")
  const[exmId,setExamId]=useState("")
  const[stuId,setStudentID]=useState("")
  const[clssid,setClassId]=useState("")
  const[subId,setSubjectId]=useState("")
  let [mark,setMarsk]=useState(0)
  const [Marks,GetMarks]=useState([]);
  useEffect(()=>{
    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };
    GetMarks([{
        "marksId": marksId,
        "exmId": exmId,
        "stuId": stuId,
        "clssId": clssid,
        "subId": subId,
        "mark": mark
      }])
  }},[])
  

    
    // useEffect(()=>{
    //     // setdata(stdData)
    //     getData()
    // },[])


    const handleUpdate = (e)=>{
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
        e.preventDefault();

        console.log("check");
        const url ='http://localhost:5297/api/Result/AddResult'
        const data = {
            "marksId": marksId,
            "examName": exmId,
            "stuId": stuId,
            "clssId": clssid,
            "subId": subId,
            "mark": mark
          }
       console.log(data);
       
       axios.post(url,data,{headers})
       .then((result)=>{
         console.log("Entered into edit api");
         handleClose()
         console.log(result.data);
         //GetSchedules(); 
         // clear();
         toast.success("Mark Added has been added")
       })
       .catch((error)=>{
         console.log(error)
       })
       }}



       useEffect(()=>{
        if (sessionStorage.getItem("token") != null) {
          console.log(sessionStorage.getItem("token"));
          const headers = {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          };
        axios
            .get("http://localhost:5297/api/ScheduleClass/GetAll",{headers})
            .then((response)=>{
                console.log(response.data);//return dta send by json
            //  /dd response data to student state
            })
            .catch((error)=>{
                console.log(error);
            });
    }},[handleShow]);


    
    return(

        <div>
        <div className="container">
            <h1>Student Marks</h1>
            <br/><br/>
            <table className="table table-striped">
                <thead>
                    {/* <tr> */}
                        {/* <th>TeacherID</th> */}
                        {/* <th>Marks ID</th>
                        <th>Exam ID</th>
                        <th>StudentID</th> */}
                        {/* <th>phone Number</th> */}
                        {/* <th>Class ID</th>
                        <th>Subject ID</th>
                        <th>Marks</th>
                        
                    </tr> */}
                </thead>
                <tbody>
                {
            //   <tr>
            //     <td>{Marks.marksId}</td>
            //     <td>{Marks.exmId}</td>
            //     <td>{Marks.stuId}</td>
            //     <td>{Marks.clssId}</td>
            //     <td>{Marks.subId}</td>
            //     <td>{Marks.mark}</td>
                
                <button className='btn btn-warning' onClick={handleShow} style={{float:"left",padding:"13px"}}>Add Student Mark</button> 
              
                  }  {/* </tr> */}
           
              
          {/* } */}
        
                </tbody>
            </table>
        </div>
     
<Fragment>
 <ToastContainer/>
 <Container>

<Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add marks</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Row>
        <Col>
        <input type="text" className='form-control' placeholder='marksId'
         onChange={(e)=> setmarksId(e.target.value)} />
        </Col>
        </Row>
        <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='exmId '
         onChange={(e)=> setExamId(e.target.value)} />
        </Col>
        </Row>
        <Row>
        <Col>
        <input type="text" className='form-control' placeholder='stuId '
        onChange={(e)=> setStudentID(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='clssId '
         onChange={(e)=> setClassId(e.target.value)} />
        </Col>
      </Row>
      <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='subId'
        onChange={(e)=> setSubjectId(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='mark'
        onChange={(e)=> setMarsk(e.target.value)} />
        </Col>
      </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleUpdate}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
</Container>
</Fragment> 

</div>

    )
}
export default AddMarks;
