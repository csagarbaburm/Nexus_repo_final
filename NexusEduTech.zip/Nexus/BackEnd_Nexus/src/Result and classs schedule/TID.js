import React, { useState,useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
 
const TId = () => {
  const [teacherId, setId] = useState("");
  const [scheduleDetails, setScheduleDetails] = useState([]); // State variable to store teacher details
  const [error, setError] = useState("");
 let navigate=useNavigate();
  const [optionTec,setoptionTec] = useState([])
 
  useEffect(() => {
    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };
    axios.get('http://localhost:5297/api/Teacher/GetAllTeachers',{headers})
        .then((result) => {
          setoptionTec(result.data);
        })
        .catch((error) => {
            console.log(error);
         
        });

          if(sessionStorage.getItem("token")==null){
              navigate('/loginpages')
          }

 
}}, []);
 
 
  const getById = async () => {
    if (!teacherId) {
      setError("Please enter a valid teacher ID");
      return;
    }
 
    try {
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
      const response = await axios.get(
        "http://localhost:5297/api/ScheduleClass/GetClassByTeacherId/" + teacherId
      ,{headers});
      console.log(response.data);
      setScheduleDetails(response.data); // Update state with fetched teacher details
      setError("");
    } }catch (error) {
      console.log(error);
      setError("Error fetching class details. Please try again.");
    }
  };
 
  return (
    <div className="container">
      <h1>Get Class By TeacherID</h1>
      <br />
      <div className="col-12 col-md-6">
        {/* <input
          placeholder="Enter the TeacherId"
          type="text"
          value={teacherId}
          onChange={(e) => setId(e.target.value)}
        style={{marginRight:"10px"}} />
         */}
         <select
        aria-label="Select Teacher"
        name="TeacherClass"
        className="form-control form-control-sm "
        value={teacherId}
        onChange={(e) => setId(e.target.value)}>
        <option key="default" value="">
            Select Teacher
        </option>
        {optionTec.map((option) => (
            <option key={option.teacherId} value={option.teacherId}>
                {option.firstName}
            </option>
      ))}
      </select>
      <div className="pt-2">
        <button className="btn btn-primary" onClick={getById}>
          Get Class By TID
        </button>
        </div>
        {error && <p className="text-danger">{error}</p>}
      </div>
      {scheduleDetails && (
        <table className="table">
          <thead>
            <tr>
              <th>Session Time</th>
              <th>Subject Name</th>
              <th>Class Name</th>
            </tr>
          </thead>
          <tbody>
            {scheduleDetails.map((schedule) => {
              return (
                <tr>
                  <td>{schedule.sessionTime}</td>
                  <td>{schedule.subName}</td>
                  <td>{schedule.className}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
};
 
export default TId;