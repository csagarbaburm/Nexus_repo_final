import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
    import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import { useNavigate } from 'react-router-dom';
 
const ScheduleClassesCRUD=()=>{
 
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  let navigate=useNavigate();

      //Edit
      const [optionCls,setoptionCls] = useState([])
      const [optionSub,setoptionSub] = useState([])
      const [optionTec,setoptionTec] = useState([])
 
      useEffect(() => {
        if (sessionStorage.getItem("token") != null) {
          console.log(sessionStorage.getItem("token"));
          const headers = {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          };
        axios.get('http://localhost:5297/api/Class/GetAllClass',{headers})
            .then((result) => {
              setoptionCls(result.data);
            })
            .catch((error) => {
                console.log(error);
                toast.error(error)
            });
            axios.get('http://localhost:5297/api/Subject/GetAllSubjects',{headers})
            .then((result) => {
              setoptionSub(result.data);
            })
            .catch((error) => {
                console.log(error);
                toast.error(error)
            });
            axios.get('http://localhost:5297/api/Teacher/GetAllTeachers',{headers})
            .then((result) => {
              setoptionTec(result.data);
            })
            .catch((error) => {
                console.log(error);
                toast.error(error)
            });

              if(sessionStorage.getItem("token")==null){
                  navigate('/loginpages')
              }

    }}, []);
 
  const[UScheId,setUScheId]=useState("")
  const[UClsId,setUClsId]=useState("")
  const[USessionTime,setUSession]=useState("")
  const[UTeachId,setUTeachId]=useState("")
  const[USubId,setUSubId]=useState("")
  let [update,setupdate]=useState(0)
  const [schedule,GetSchedules]=useState([]);
 
 
 
 
 
 
   
    // useEffect(()=>{
    //     // setdata(stdData)
    //     getData()
    // },[])
 
 
    const handleUpdate = (e)=>{
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
        e.preventDefault();
        setupdate(update+1);
        console.log("check");
        const url ='http://localhost:5297/api/ScheduleClass/Update'
        const data = {
            scheduleId: UScheId,
            classId: UClsId,
            sessionTime: USessionTime,
            teacId: UTeachId,
            subjId: USubId
       }
       console.log(data);
       
       axios.put(url,data,{headers})
       .then((result)=>{
         console.log("Entered into edit api");
         handleClose()
         console.log(result.data);
         //GetSchedules();
         // clear();
         toast.success("Schedules has been updated")
       })
       .catch((error)=>{
         console.log(error)
       })
       }}
 
 
 
       useEffect(()=>{
        if (sessionStorage.getItem("token") != null) {
          console.log(sessionStorage.getItem("token"));
          const headers = {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          };
        axios
            .get("http://localhost:5297/api/ScheduleClass/GetAll",{headers})
            .then((response)=>{
                console.log(response.data);//return dta send by json
                GetSchedules(response.data);//add response data to student state
            })
            .catch((error)=>{
                console.log(error);
            });
    }},[handleShow]);
 
 
   
    return(
 
        <div>
        <div className="container">
            <h1>Class Schedule</h1>
            <br/><br/>
            <table className="table table-striped">
                <thead>
                    <tr>
                        {/* <th>TeacherID</th> */}
                        <th>Schedule ID</th>
                        <th>Session Time</th>
                        <th>Class Name</th>
                        {/* <th>phone Number</th> */}
                        <th>Teacher Name</th>
                        <th>Subject Name</th>
                       
                    </tr>
                </thead>
                <tbody>
                {schedule.length > 0 && (
          schedule.map((schedule)=>{
            return(
              <tr>
                <td>{schedule.scheduleId}</td>
                <td>{schedule.sessionTime}</td>
                <td>{schedule.className}</td>
                <td>{schedule.teachName}</td>
                <td>{schedule.subName}</td>
 
                <button className='btn btn-warning' onClick={handleShow} style={{float:"left",padding:"13px"}}>Update</button> &nbsp;
              </tr>
            )
          })
        )}
                </tbody>
            </table>
        </div>
     
<Fragment>
 <ToastContainer/>
 <Container className='form-group'>
 
<Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modify /Update Schedule</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Row>
        {/* <Col>
        <input type="text" className='form-control' placeholder='Class ID'
         onChange={(e)=> setUClsId(e.target.value)} />
        </Col> */}
 
<Col>
 <select
   aria-label="Select Class"
    name="className"
    className="form-control form-control-sm"
    value={UClsId}
    onChange={(e) => setUClsId(e.target.value)}>
    <option key="default" value="">
        Select Class
    </option>
    {optionCls.map((option) => (
        <option key={option.classId} value={option.classId}>
            {option.name}
        </option>
 ))}
 </select>
   </Col>
        </Row>
        <Row className='pt-2'>
        <Col className=''>
        <input type="text" className='form-control form-control-sm' placeholder='Schedule ID'
         onChange={(e)=> setUScheId(e.target.value)} />
        </Col>
        </Row>
        <Row>
 
        <div className='form-group pt-2'>
        <Col>
       
        <input type="text" className='form-control form-control-sm' placeholder='Session Time'
        onChange={(e)=> setUSession(e.target.value)} />
        </Col>
 
     
        {/* <Col>
        <input type="text" className='form-control' placeholder='Subject ID'
         onChange={(e)=> setUSubId(e.target.value)} />
        </Col> */}
<div className='form-group pt-2'></div>
<Col>
 
  <select
  aria-label="Select Subject"
   name="className"
   className="form-control form-control-sm"
   value={USubId}
   onChange={(e) => setUSubId(e.target.value)}>
   <option key="default" value="">
       Select Subject
   </option>
   {optionSub.map((option) => (
       <option key={option.subId} value={option.subId}>
           {option.subName}
       </option>
))}
</select>
</Col>
</div>
 
  {/* </Col>
      </Row>
      <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='Teacher ID'
        onChange={(e)=> setUTeachId(e.target.value)} />
        </Col> */}
 
<Col className='pt-2'>
 
  <select
  aria-label="Select Teacher"
   name="className"
   className="form-control form-control-sm"
   value={UTeachId}
   onChange={(e) => setUTeachId(e.target.value)}>
   <option key="default" value="">
   
       Select Teacher
   </option>
   {optionTec.map((option) => (
       <option key={option.teacherId} value={option.teacherId}>
           {option.firstName}
       </option>
))}
</select>
  </Col>
                   
      </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleUpdate}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
</Container>
</Fragment>
 
</div>
 
    )
}
export default ScheduleClassesCRUD;