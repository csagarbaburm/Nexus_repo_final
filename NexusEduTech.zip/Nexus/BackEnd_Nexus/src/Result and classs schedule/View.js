import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import { useNavigate } from "react-router-dom";


  const GetSchedule=()=>{


    let navigate=useNavigate();
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
      //Edit
  const[UScheId,setUScheId]=useState("")
  const[UClsId,setUClsId]=useState("")
  const[USessionTime,setUSession]=useState("")
  const[UTeachId,setUTeachId]=useState("")
  const[USubId,setUSubId]=useState("")
  
  const [schedule,GetSchedules]=useState([]);

    useEffect(()=>{
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
        axios
            .get("http://localhost:5297/api/ScheduleClass/GetAll",{headers})
            .then((response)=>{
                console.log(response.data);//return dta send by json
                GetSchedules(response.data);//add response data to student state
            })
            .catch((error)=>{
                console.log(error);
            });
    }},[schedule]);

    useEffect(()=>{
      if(sessionStorage.getItem("token")==null){
          navigate('/loginpages')
      }
  })
    
    return(
       <div>
        <div className="container">
            <h1>Class Schedule</h1>
            <br/><br/>
            <table className="table table-striped">
                <thead>
                    <tr>
                        {/* <th>TeacherID</th> */}
                        {/* <th>Schedule Id</th> */}
                        <th>Session Time</th>
                        <th>Class Name</th>
                        {/* <th>phone Number</th> */}
                        <th>Teacher Name</th>
                        <th>Subject Name</th>
                    </tr>
                </thead>
                <tbody>
                {schedule.length > 0 && (
          schedule.map((schedule)=>{
            return(
              <tr>
                {/* <td>{schedule.scheduleId}</td> */}
                <td>{schedule.sessionTime}</td>
                <td>{schedule.className}</td>
                <td>{schedule.teachName}</td>
                <td>{schedule.subName}</td>
                
              </tr>
            )
          })
        )}
                </tbody>
            </table>
        </div>


</div>
 )
}
export default GetSchedule;
