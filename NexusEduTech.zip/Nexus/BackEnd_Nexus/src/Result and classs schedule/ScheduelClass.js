import React, { useState, useEffect, Fragment } from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ScheduleExam from "../Teacher/schedule-exam";
import { useNavigate } from "react-router-dom";


const ScheduleClass = () => {
    let navigate = useNavigate();

    const [Schedid, setId] = useState("");
    const [Clsid, setCid] = useState("");
    const [SessionTime, setSession] = useState("");
    const [Teacid, setTeacId] = useState("");
    const [Subjid, setSubId] = useState("");
    const [optionCls, setOptionCls] = useState([]);
    const [optionSub, setOptionSub] = useState([]);
    const [optionTec, setOptionTec] = useState([]);
    const [errors, setErrors] = useState({});

    useEffect(() => {
        if (sessionStorage.getItem("token") != null) {
            const headers = {
                Authorization: `Bearer ${sessionStorage.getItem("token")}`,
            };
            axios.get('http://localhost:5297/api/Class/GetAllClass', { headers })
                .then((result) => {
                    setOptionCls(result.data);
                })
                .catch((error) => {
                    console.log(error);
                    toast.error(error)
                });
            axios.get('http://localhost:5297/api/Subject/GetAllSubjects', { headers })
                .then((result) => {
                    setOptionSub(result.data);
                })
                .catch((error) => {
                    console.log(error);
                    toast.error(error)
                });
            axios.get('http://localhost:5297/api/Teacher/GetAllTeachers', { headers })
                .then((result) => {
                    setOptionTec(result.data);
                })
                .catch((error) => {
                    console.log(error);
                    toast.error(error)
                });
        }
    }, []);

    const Add = () => {
        const newErrors = {};

        if (!Schedid) {
            newErrors.Schedid = "Schedule ID is required";
        }
        if (!Clsid) {
            newErrors.Clsid = "Class ID is required";
        }
        if (!SessionTime) {
            newErrors.SessionTime = "Session Time is required";
        }
        if (!Teacid) {
            newErrors.Teacid = "Teacher ID is required";
        }
        if (!Subjid) {
            newErrors.Subjid = "Subject ID is required";
        }

        setErrors(newErrors);

        if (Object.values(newErrors).every(error => !error)) {
            if (sessionStorage.getItem("token") != null) {
                const headers = {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                };
                const schedule = {
                    scheduleId: Schedid,
                    classId: Clsid,
                    sessionTime: SessionTime,
                    teacId: Teacid,
                    subjId: Subjid,
                };
                axios
                    .post("http://localhost:5297/api/ScheduleClass/AddSchedule", schedule, { headers })
                    .then((response) => {
                        console.log(response.data);
                        toast.success("Added successfully");
                        clear();
                    })
                    .catch((error) => console.log(error));
            }
        }
    };

    const clear = () => {
        setId("");
        setCid("");
        setSession("");
        setTeacId("");
        setSubId("");
        setErrors({});
    }

    return (
        <Fragment>
            <ToastContainer />
            <Container>
                <h1>Schedule Class</h1>
                <br />
                <Row>
                    <Col>
                        <input type="text" className='form-control form-control-sm' placeholder='Enter Schedule Id '
                            value={Schedid} onChange={(e) => setId(e.target.value)} />
                        <span className="text-danger">{errors.Schedid}</span>
                    </Col>
                </Row>
                <Row className='pt-2'>
                    <Col>
                        <select
                            aria-label="Select Class"
                            name="className"
                            className="form-control form-control-sm"
                            value={Clsid}
                            onChange={(e) => setCid(e.target.value)}>
                            <option key="default" value="">
                                Select Class
                            </option>
                            {optionCls.map((option) => (
                                <option key={option.classId} value={option.classId}>
                                    {option.name}
                                </option>
                            ))}
                        </select>
                        <span className="text-danger">{errors.Clsid}</span>
                    </Col>
                    <Col>
                        <input type="text" className='form-control form-control-sm' placeholder='Enter Session Time '
                            value={SessionTime} onChange={(e) => setSession(e.target.value)} />
                        <span className="text-danger">{errors.SessionTime}</span>
                    </Col>
                </Row>
                <Row className='pt-2'>
                    <Col>
                        <select
                            aria-label="Select Teacher"
                            name="className"
                            className="form-control form-control-sm"
                            value={Teacid}
                            onChange={(e) => setTeacId(e.target.value)}>
                            <option key="default" value="">
                                Select Teacher
                            </option>
                            {optionTec.map((option) => (
                                <option key={option.teacherId} value={option.teacherId}>
                                    {option.firstName}
                                </option>
                            ))}
                        </select>
                        <span className="text-danger">{errors.Teacid}</span>
                    </Col>
                    <Col>
                        <select
                            aria-label="Select Subject"
                            name="className"
                            className="form-control form-control-sm"
                            value={Subjid}
                            onChange={(e) => setSubId(e.target.value)}>
                            <option key="default" value="">
                                Select Subject
                            </option>
                            {optionSub.map((option) => (
                                <option key={option.subId} value={option.subId}>
                                    {option.subName}
                                </option>
                            ))}
                        </select>
                        <span className="text-danger">{errors.Subjid}</span>
                    </Col>
                </Row>
                <Row className='pt-2'>
                    <Col>
                        <button className='btn btn-primary ' onClick={() => Add()}>Add Schedule</button>
                    </Col>
                </Row>
            </Container>
        </Fragment>
    )
};
export default ScheduleClass;