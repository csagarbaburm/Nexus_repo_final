import React, { useState } from 'react';
import emailjs from '@emailjs/browser';
import Back from "../common/back/Back"
import "./contact.css"
 
const Contact = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
 
  const handleSubmit = (e) => {
      e.preventDefault();
 const serviceId ='service_dhxv6vb'
 const templateID ='template_xgy4jrg';
 const publicKey ='zMoLmIWB__ysOC9JU';
 const templateParams ={
  from_name: name,
  from_email: email,
  to_name: name,
  message: message,
 };
 emailjs.send(serviceId,templateID,templateParams,publicKey)
.then((response)=>{
    console.log('Email send sucessfully',response)
    setName('');
    setEmail('');
    setMessage('');
    window.alert('Message sent sucessfully.')
})
.catch((error)=>{
    console.error('Error sending email',error);
});
    }
  const map = 'https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d904726.6131739549!2d85.24565535!3d27.65273865!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2snp!4v1652535615693!5m2!1sen!2snp" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" '
  return (
    <>
      <Back title='Contact us' />
      <section className='contacts padding'>
        <div className='container shadow flexSB'>
          <div className='left row'>
            <iframe src={map}></iframe>
          </div>
          <div className='right row'>
            <h1>Contact us</h1>
            <p>We're open for any suggestion or just to have a chat</p>
 
            <div className='items grid2'>
              <div className='box'>
                <h4>ADDRESS:</h4>
                <p>198 West 21th Street, Suite 721 New York NY 10016</p>
              </div>
              <div className='box'>
                <h4>EMAIL:</h4>
                <p> nexus@university.com</p>
              </div>
              <div className='box'>
                <h4>PHONE:</h4>
                <p> + 1235 2355 98</p>
              </div>
            </div>
 
            <form action='' onSubmit={handleSubmit} >
              <div className='flexSB'>
                <input type='text' placeholder='Name'   value={name}
                onChange={(e) => setName(e.target.value)} />
                <input type='email' placeholder='Email' value={email}
                onChange={(e) => setEmail(e.target.value)} />
              </div>
              <input type='text' placeholder='Subject' />
              <textarea cols='30' rows='10'>
                Create a message here...
              </textarea>
              <button className='primary-btn'>SEND MESSAGE</button>
            </form>
 
            <h3>Follow us here</h3>
            <span>FACEBOOK TWITTER INSTAGRAM DRIBBBLE</span>
          </div>
        </div>
      </section>
    </>
  )
}
 
export default Contact