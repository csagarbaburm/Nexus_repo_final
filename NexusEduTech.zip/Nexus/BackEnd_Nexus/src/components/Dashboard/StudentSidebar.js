import React, { useEffect, useState } from 'react';
import { FaTh, FaBars, FaUserAlt, FaRegChartBar, FaChalkboardTeacher, FaUserGraduate, FaCalendarAlt } from "react-icons/fa";
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import styles from "./Sidebar.module.css"
import axios from 'axios';


 const StudentSidebar = ({ children }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [activeIndex, setActiveIndex] = useState(null);
    let [username,setUsername]=useState("User")
    
    const [userid,setuserid]=useState("")
    let navigate=useNavigate();
    
    function getstudent(){
        console.log("USerID is:",userid);
        axios.post(`http://localhost:5297/api/User/GetUserbyUsername/${username}`)
        .then((response)=>{console.log(response.data);
        setuserid(response.data.userId);
       // sessionStorage.setItem("USERID",response.data.userId);
        }
        )
        .catch((e)=>console.log(e))
    }


    useEffect(()=>{
        getstudent();

    },[])

    // / setUsername(sessionStorage.getItem(username))
    const toggleSidebar = () => {
        setIsOpen(!isOpen);
    };
    
    useEffect(()=>{
        setUsername(sessionStorage.username)
    },[])

    const toggleSubMenu = (index) => {
        setActiveIndex(activeIndex === index ? null : index);
    };

    const menuItem = [
        {
            path: "/student-dashboard",
            name: "Student",
            icon: <FaTh />,
            submenu: null
        },

        {
            path: "/",
            name: "Class Schedules",
            icon: <FaCalendarAlt />,
            submenu: [
               
                { path: "viewscheduleclass", icon: <FaCalendarAlt />, name: "View Class Details" }
              
            ]
        },
        {
            path: "/student-dashboard",
            name: "Exam Schedules",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "scheduleexam", icon: <FaCalendarAlt />, name: "View Exam Schedule" }      
            ]
        },
        {
            path: "/student-dashboard",
            name: "Attendance",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "studentattendancereport", icon: <FaCalendarAlt />, name: " Student Attendance Report" } 
            ]
        },
        {
            path: "/student-dashboard",
            name: "Result",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "showresult", icon: <FaCalendarAlt />, name: "Show result" }      
            ]
        },
        {
            path: "/student-dashboard",
            name: "Notification",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "studentNotification", icon: <FaCalendarAlt />, name: "Show notifications" }      
            ]
        }



        
    ];

    return (
        <div className={styles.container}>
            <div style={{ width: isOpen ? "200px" : "200px" }} className={styles.sidebar}>
                <div className={styles.top_section}>
                    <h1 style={{ display: isOpen ? "block" : "none" }} className={styles.logo}>Logo</h1>
                    <div style={{ marginLeft: isOpen ? "50px" : "0px"}} className={styles.bars}>
                        <FaBars onClick={toggleSidebar} />
                    </div>
                </div>
                {
                    menuItem.map((item, index) => (
                        <div key={index}>
                            <div className={styles.link} onClick={() => toggleSubMenu(index)}>
                                <div className={styles.icon}>{item.icon}</div>
                                <div className={styles.link_text}>{item.name}</div>
                            </div>
                            {activeIndex === index && item.submenu && (
                                <ul className={styles.submenu} style={{color:"white"}}>
                                    {item.submenu.map((subItem, subIndex) => (
                                        <li key={subIndex}>
                                            <NavLink to={subItem.path} className={styles.submenulink}>{subItem.icon}{subItem.name}</NavLink>
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    ))
                }
            </div>
            <div className={styles.content}>
                <div className={styles.navbar} style={{textAlign: "right", backgroundColor: "#555"}}>
                    <ul>
                        <li><a href="#">Welcome, {username}</a> |</li>
                        <li> <Link to="/">Logout</Link></li>
                        <li><Link to="/student-dashboard">Home</Link></li>
                      
                    </ul>
                </div>
                <main className='container' style={{height:'700px'}}>{children}
                {/* <RegistrationPage/> */}
                <Outlet/>
                </main>
                {/* <footer className={styles.footer}>
                    <p>&copy; 2024 Nexus</p>
                </footer> */}
            </div>
        </div>
      
    );
};

export default StudentSidebar;
