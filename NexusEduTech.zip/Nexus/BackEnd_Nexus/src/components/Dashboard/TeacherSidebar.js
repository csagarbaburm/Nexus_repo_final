import React, { useEffect, useState } from 'react';
import { FaTh, FaBars, FaUserAlt, FaRegChartBar, FaChalkboardTeacher, FaUserGraduate, FaCalendarAlt } from "react-icons/fa";
import { Link, NavLink, Outlet } from 'react-router-dom';
import styles from "./Sidebar.module.css"


 const TeacherSidebar = ({ children }) => {
    useEffect(()=>{},[])
    const [isOpen, setIsOpen] = useState(false);
    const [activeIndex, setActiveIndex] = useState(null);
    let [username,setUsername]=useState("User")

    // / setUsername(sessionStorage.getItem(username))
    const toggleSidebar = () => {
        setIsOpen(!isOpen);
    };
    
    useEffect(()=>{
        setUsername(sessionStorage.username)
    },[])

    const toggleSubMenu = (index) => {
        setActiveIndex(activeIndex === index ? null : index);
    };

    const menuItem = [
        {
            path: "/",
            name: "Dashboard",
            icon: <FaTh />,
            submenu: null
        },
        {
            path: "/teacher-dashboard",
            name: "Student Management",
            icon: <FaUserGraduate />,
            submenu: [
                { path: "getbyroll", icon: <FaUserAlt />, name: "View Student Details" },
                { path: "crud", icon: <FaUserAlt />, name: "View all students" },
                { path: "getbycls", icon: <FaUserAlt />, name: "Get Students by class" },
                { path: "getbyclssec", icon: <FaUserAlt />, name: "Get Students by class and section" }
            ]
        },
        {
            path: "/teacher-dashboard",
            name: "Class Schedule",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "viewscheduleclass", icon: <FaCalendarAlt />, name: "View Class Details" }
            ]
        },
        {
            path: "/teacher-dashboard",
            name: "Attendance",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "studentattendance", icon: <FaCalendarAlt />, name: " Student Attendance" },
                { path: "teacherattendancereport", icon: <FaCalendarAlt />, name: " Teacher Attendance Report" },
                { path: "studentattendancereport", icon: <FaCalendarAlt />, name: " Student Attendance Report" }          
            ]
        },
        {
            path: "/teacher-dashboard",
            name: "Marks and Result",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "showresult", icon: <FaCalendarAlt />, name: "Student result" },
                { path: "addmarks", icon: <FaCalendarAlt />, name: "Add marsks" }            
            ]
        },
        {
            path: "/teacher-dashboard",
            name: "Notification",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "teachernotification", icon: <FaCalendarAlt />, name: "Show notifications" }      
            ]
        }



        
    ];

    return (
        <div className={styles.container}>
            <div style={{ width: isOpen ? "200px" : "200px" }} className={styles.sidebar}>
                <div className={styles.top_section}>
                    <h1 style={{ display: isOpen ? "block" : "none" }} className={styles.logo}>Logo</h1>
                    <div style={{ marginLeft: isOpen ? "50px" : "0px"}} className={styles.bars}>
                        <FaBars onClick={toggleSidebar} />
                    </div>
                </div>
                {
                    menuItem.map((item, index) => (
                        <div key={index}>
                            <div className={styles.link} onClick={() => toggleSubMenu(index)}>
                                <div className={styles.icon}>{item.icon}</div>
                                <div className={styles.link_text}>{item.name}</div>
                            </div>
                            {activeIndex === index && item.submenu && (
                                <ul className={styles.submenu} style={{color:"white"}}>
                                    {item.submenu.map((subItem, subIndex) => (
                                        <li key={subIndex}>
                                            <NavLink to={subItem.path} className={styles.submenulink}>{subItem.icon}{subItem.name}</NavLink>
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    ))
                }
            </div>
            <div className={styles.content}>
                <div className={styles.navbar} style={{textAlign: "right", backgroundColor: "#555"}}>
                    <ul>
                        <li><a href="#">Welcome, {username}</a> |</li>
                       <li> <Link to="/">Logout</Link></li>
                        <li><Link to="/teacher-dashboard">Home</Link></li>
                      
                    </ul>
                </div>
                <main className='container' style={{height:'700px'}}>{children}
                {/* <RegistrationPage/> */}
                <Outlet/>
                </main>
                {/* <footer className={styles.footer}>
                    <p>&copy; 2024 Nexus</p>
                </footer> */}
            </div>
        </div>
      
    );
};

export default TeacherSidebar;
