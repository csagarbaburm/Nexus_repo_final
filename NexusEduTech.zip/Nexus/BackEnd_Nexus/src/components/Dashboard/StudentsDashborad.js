import React from 'react';
import Sidebar from './AdminSidebar';
import StudentSidebar from './StudentSidebar';


const StudentDashboard = () => {
    return (
        <div>
            <StudentSidebar/>
            {/* <h1>dashboard page</h1> */}
        </div>
    );
};

export default StudentDashboard;