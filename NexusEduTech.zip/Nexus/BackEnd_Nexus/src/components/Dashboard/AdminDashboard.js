import React from 'react';

import AdminSidebar from './AdminSidebar';

const AdminDashboard = () => {
    return (
        <div>
            <AdminSidebar/>
            {/* <h1>dashboard page</h1> */}
        </div>
    );
};

export default AdminDashboard;