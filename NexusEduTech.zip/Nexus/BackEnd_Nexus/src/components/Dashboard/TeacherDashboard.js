import React from 'react';
import Sidebar from './AdminSidebar';
import TeacherSidebar from './TeacherSidebar';
const TeacherDashboard = () => {
    return (
        <div>
            <TeacherSidebar/>
            {/* <h1>dashboard page</h1> */}
        </div>
    );
};

export default TeacherDashboard;