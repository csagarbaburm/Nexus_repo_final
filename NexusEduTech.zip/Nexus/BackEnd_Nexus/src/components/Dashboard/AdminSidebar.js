import React, { useEffect, useState } from 'react';
import { FaTh, FaBars, FaUserAlt, FaRegChartBar, FaChalkboardTeacher, FaUserGraduate, FaCalendarAlt } from "react-icons/fa";
import { Link, NavLink, Outlet } from 'react-router-dom';
import styles from "./Sidebar.module.css"

import { Carousel } from 'react-bootstrap';

 const AdminSidebar = ({ children }) => {
    useEffect(()=>{},[])
    const [isOpen, setIsOpen] = useState(false);
    const [activeIndex, setActiveIndex] = useState(null);
    let [username,setUsername]=useState("User")

    // / setUsername(sessionStorage.getItem(username))
    const toggleSidebar = () => {
        setIsOpen(!isOpen);
    };
    
    useEffect(()=>{
        setUsername(sessionStorage.username)
    },[])

    const toggleSubMenu = (index) => {
        setActiveIndex(activeIndex === index ? null : index);
    };

    const menuItem = [

        {
            path: "/admin-dashboard",
            name: "Student Management",
            icon: <FaUserGraduate />,
            submenu: [
                { path: "getbyroll", icon: <FaUserAlt />, name: "View Student Details" },
                { path: "crud", icon: <FaUserAlt />, name: "View all students" },
                { path: "getbycls", icon: <FaUserAlt />, name: "Get Students by class" },
                { path: "getbyclssec", icon: <FaUserAlt />, name: "Get Students by class and section" }
            ]
        },
        {
            path: "/admin-dashboard",
            name: "Teacher Management",
            icon: <FaChalkboardTeacher />,
            submenu: [
                { path: "gettechbyid", icon: <FaUserAlt />, name: "View Teacher Details" },
                { path: "teachercrud", icon: <FaUserAlt />, name: "Add Teacher" },
                { path: "getbysub", icon: <FaUserAlt />, name: "View Teacher by subject" }
               
            ]
        },
        {
            path: "/admin-dashboard",
            name: "Class Schedule",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "classschedulebyid", icon: <FaCalendarAlt />, name: "View Scheduled teachers by class ID" },
                { path: "classschedulebytid", icon: <FaCalendarAlt />, name: "View Scheduled Classes by Teacher ID" },
                { path: "viewscheduleclass", icon: <FaCalendarAlt />, name: "View Class Details" },
                { path: "scheduleclass-add", icon: <FaCalendarAlt />, name: "Schedule Classes-Add" },
                { path: "scheduleclasses-update-get", icon: <FaCalendarAlt />, name: "Schedule Classes-Update & view" },

              
            ]
        },
        {
            path: "/admin-dashboard",
            name: "Exam Schedule",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "scheduleexam", icon: <FaCalendarAlt />, name: "Schedule Exams" }   
            ]
        },
        {
            path: "/admin-dashboard",
            name: "Attendance",
            icon: <FaCalendarAlt />,
            submenu: [
                // { path: "studentattendance", icon: <FaCalendarAlt />, name: " Student Attendance" },
                { path: "teacherattendance", icon: <FaCalendarAlt />, name: " Teacher Attendance" },
                { path: "teacherattendancereport", icon: <FaCalendarAlt />, name: " Teacher Attendance Report" },
                { path: "studentattendancereport", icon: <FaCalendarAlt />, name: " Student Attendance Report" }         

                
            ]
        },
        {
            path: "/admin-dashboard",
            name: "Result",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "showresult", icon: <FaCalendarAlt />, name: "Show result" }      
            ]
        },
        {
            path: "/admin-dashboard",
            name: "Notification",
            icon: <FaCalendarAlt />,
            submenu: [
                { path: "communication", icon: <FaCalendarAlt />, name: "Communication" },
                { path: "notification", icon: <FaCalendarAlt />, name: "Alert-Notification" }      
            ]
        }




        
    ];

    return (
        <div className={styles.container}>
            <div style={{ width: isOpen ? "200px" : "200px" }}  className={styles.sidebar}>
                <div className={styles.top_section}>
                    <h1 style={{ display: isOpen ? "block" : "none" }} className={styles.logo}></h1>
                    <div style={{ marginLeft: isOpen ? "50px" : "50px"}} className={styles.bars}>
                        <FaBars onClick={toggleSidebar} />
                    </div>
                </div>
                {
                    menuItem.map((item, index) => (
                        <div key={index}>
                            <div className={styles.link} onClick={() => toggleSubMenu(index)}>
                                <div className={styles.icon}>{item.icon}</div>
                                <div className={styles.link_text}>{item.name}</div>
                            </div>
                            {activeIndex === index && item.submenu && (
                                <ul className={styles.submenu} style={{color:"white"}}>
                                    {item.submenu.map((subItem, subIndex) => (
                                        <li key={subIndex}>
                                            <NavLink to={subItem.path} className={styles.submenulink}>{subItem.icon}{subItem.name}</NavLink>
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    ))
                }
            </div>
            <div className={styles.content}>
                <div className={styles.navbar} style={{textAlign: "right", background:"#5390e0"}}>
                    <ul>
                        <li><a href="#">Welcome, {username}</a> |</li>
                        <li> <Link to="/">Logout</Link></li>
                        <li><Link to="/admin-dashboard">Home</Link></li>
                      
                    </ul>
                </div>
                <main className='container' style={{height:'700px'}}>{children}
                
                {/* <RegistrationPage/> */}
                <Outlet/>
               
                </main>
                {/* <footer className={styles.footer}>
                    <p>&copy; 2024 Nexus</p>
                </footer> */}
            </div>
        </div>
      
    );
};

export default AdminSidebar;
