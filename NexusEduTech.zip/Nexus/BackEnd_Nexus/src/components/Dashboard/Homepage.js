import { useEffect } from "react";
import { Carousel } from "react-bootstrap";
import { useNavigate } from "react-router-dom";


function HomePage() {

    const navigate=useNavigate();

    useEffect(()=>{
        if(sessionStorage.getItem("token")==null){
            navigate('/loginpages')
        }
    })


    return ( 
         
        <main>
             <Carousel>
                    <Carousel.Item>
                        <img
                            className="d-block w-100"
                            src="https://quotefancy.com/media/wallpaper/3840x2160/50568-Daniel-J-Boorstin-Quote-Education-is-learning-what-you-didn-t-even.jpg"
                            alt="First slide"
                        />

                    </Carousel.Item>
                    <Carousel.Item>
                        <img
                            className="d-block w-100"
                            src="https://via.placeholder.com/800x400"
                            alt="Second slide"
                        />
 
                    </Carousel.Item>
                    <Carousel.Item>
                        <img
                            className="d-block w-100"
                            src="https://via.placeholder.com/800x400"
                            alt="Third slide"
                        />
 
                        <Carousel.Caption>
                            <h3>Third slide label</h3>
                            <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                        </Carousel.Caption>
                    </Carousel.Item>
                </Carousel>
        </main>
     );
}

export default HomePage;