import React, { useState } from "react"
import { Link, Outlet, useNavigate } from "react-router-dom"
import Head from "./Head"
import "./header.css"

const Header = () => {
  const [click, setClick] = useState(false)
  let navigate=useNavigate();

  return (
    <>
      <Head />
      <header>
        <nav className='flexSB'>
          <ul className={click ? "mobile-nav" : "flexSB "} onClick={() => setClick(false)}>
            <li>
              <Link to='/'>Home</Link>
            </li>
          
            <li>
              <Link to='/about'>Case Studies</Link>
            </li>
            <li>
              <Link to='/loginpages'>Login</Link>
            </li>

            <li>
              <Link to='/registerpage'>Register</Link>
            </li>
            <li>
              <Link to='/contact'>Contact Us</Link>
            </li>
          </ul>
          
          <button className='toggle' onClick={() => setClick(!click)}>
            {click ? <i className='fa fa-times'> </i> : <i className='fa fa-bars'></i>}
          </button>
        </nav>
      </header>
      <main>
      <Outlet/>
      </main>

    </>
  )
}

export default Header
