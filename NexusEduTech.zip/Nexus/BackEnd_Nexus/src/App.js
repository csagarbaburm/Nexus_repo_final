
import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Roll from "./Admin/GetRollByRoll";
import LoginUser from "./Student/Login";
import ClassAndSec from "./Admin/GetStdByClsSec";
import Home from "./components/home/Home";
import RegistrationPage from "./Student/Register";
import Id from "./Admin/GetstudentById";
import CId from "./Admin/GetStudentByClass";
import GetExamByExamId from "./Admin/GetStudentId";
import CRUD from "./Student module/CRUD"
import CRUDd from "./TeacherModule/TeacherCrud";
import GetBYIDT from "./TeacherModule/GetByID";
import GetBySub from "./TeacherModule/GetBYSub";
import Result1 from "./Result and classs schedule/Result";
import TId from "./Result and classs schedule/TID";
import StAttendance from "./Attendance module/StudentAttendace";
import SCId from "./Result and classs schedule/CID";
import GetSchedule from "./Result and classs schedule/View";
import ScheduleClass from "./Result and classs schedule/ScheduelClass";
import ScheduleClassesCRUD from "./Result and classs schedule/GetSchedule";
import ExamCRUD from "./Exam Molude/CRUD";
import AddMarks from "./Result and classs schedule/AddMarsk";
import TeacherAttendance from "./Attendance module/TeacherAttendance";
import TeacherAttendanceReport from "./Attendance module/ViewAttendanceReport";
import StudentAttendanceReport from "./Attendance module/ViewAttendanceReportStudent";
import AdminDashboard from "./components/Dashboard/AdminDashboard";
import StudentDashboard from "./components/Dashboard/StudentsDashborad";
import TeacherDashboard from "./components/Dashboard/TeacherDashboard";
import PasswordRecovery from './Student/PasswordRecovery';
import ChangePassword from './Student/ChangePassword';
import ExamView from "./Exam Molude/ExamView";
import StudentAttendanceReportperstudent from "./Attendance module/ViewAttendanceReportStudentPerStudent copy";
import Result1perstudent from "./Result and classs schedule/Resultperstudent";
import HomePage from "./components/Dashboard/Homepage";
import HomeRegistraion from "./Student/LoginRegistration";
import { ContactUs } from "./Communication Module/EmailForm";
import AboutCard from "./components/about/AboutCard";
import Notification from "./Notification/Notification";
import StudentNotification from "./Notification/StudentNotification";
import TeacherNotification from "./Notification/TeacherNotification";
function App() {
  return (
    <div className="App">
      {/* <Header/> */}
      <BrowserRouter>
      
        <Routes>
      
          <Route path="/" element={<Home />}>
          
          <Route index element={<HomeRegistraion />} />
            <Route path="loginpages" element={<LoginUser />} />
            <Route path="registerpage" element={<RegistrationPage />} />
            <Route path="forgotpass" element={<PasswordRecovery />} />
            <Route path="changepass" element={<ChangePassword />} />
            <Route path="about" element={<AboutCard/>}/>
            
          </Route>


          <Route path="admin-dashboard" element={<AdminDashboard />}>
          <Route index element={<HomePage />} />
            <Route path="getbyroll" element={<Roll />} />
            <Route path="getbyclssec" element={<ClassAndSec />} />
            <Route path="getbycls" element={<CId />} />
            <Route path="getbyclsss" element={<Id />} />
            <Route path="getexambyid" element={<GetExamByExamId />} />
            <Route path="crud" element={<CRUD />} />
            <Route path="gettechbyid" element={<GetBYIDT />} />
            <Route path="getbysub" element={<GetBySub />} />
            <Route path="teachercrud" element={<CRUDd />} />
            <Route path="getbyid" element={<GetBYIDT />} />
            <Route path="getbysub" element={<GetBySub />} />
            <Route path="classschedulebyid" element={<SCId />} />
            <Route path="result" element={<Result1 />} />
            <Route path="classschedulebytid" element={<TId />} />
            <Route path="viewscheduleclass" element={<GetSchedule />} />
            <Route path="scheduleclass-add" element={<ScheduleClass />} />
            <Route path="scheduleclasses-update-get" element={<ScheduleClassesCRUD />} />
            <Route path="scheduleexam" element={<ExamCRUD />} />
            <Route path="studentattendance" element={<StAttendance />} />
            <Route path="teacherattendance" element={<TeacherAttendance />} />
            <Route path="teacherattendancereport" element={<TeacherAttendanceReport />} />    
            <Route path="studentattendancereport" element={<StudentAttendanceReport />} /> 
            <Route path="showresult" element={<Result1 />} />   
            <Route path="addmarks" element={<AddMarks />} />   
            <Route path="communication" element={<ContactUs />} /> 
            <Route path="notification" element={<Notification />} /> 

          </Route>
          
          <Route path="student-dashboard" element={<StudentDashboard />}>
          <Route index element={<HomePage />} />

            <Route path="getbyid" element={<Id />} />
            <Route path="getexambyid" element={<GetExamByExamId />} />
            <Route path="studentattendancereport" element={<StudentAttendanceReportperstudent />} />
            <Route path="viewscheduleclass" element={<GetSchedule />} />    
            <Route path="addmarks" element={<AddMarks />} />   
            <Route path="scheduleexam" element={<ExamView />} />
            <Route path="showresult" element={<Result1perstudent />} />
            <Route path="studentNotification" element={<StudentNotification />} />

          </Route>


          <Route path="teacher-dashboard" element={<TeacherDashboard />}>
          <Route index element={<HomePage />} />
          <Route path="getbyroll" element={<Roll />} />
          <Route path="crud" element={<CRUD />} />
          <Route path="getbycls" element={<CId />} />
          <Route path="getbyclssec" element={<ClassAndSec />} />
          <Route path="teachercrud" element={<CRUDd />} />
          <Route path="getbyid" element={<GetBYIDT />} />
          <Route path="getbysub" element={<GetBySub />} />
            <Route path="classschedulebyid" element={<SCId />} />
            <Route path="result" element={<Result1 />} />
            <Route path="viewscheduleclass" element={<GetSchedule />} />
            <Route path="studentattendance" element={<StAttendance />} />
            <Route path="showresult" element={<Result1 />} />     
            <Route path="addmarks" element={<AddMarks />} />      
            <Route path="teacherattendancereport" element={<TeacherAttendanceReport />} />    
            <Route path="studentattendancereport" element={<StudentAttendanceReport />} /> 
            <Route path="teachernotification" element={<TeacherNotification />} />   
            
          </Route>

          {/* <Route path="components" element={<Home />}></Route> */}


        
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
