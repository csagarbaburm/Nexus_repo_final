import Table from 'react-bootstrap/Table';
import React, { useState, useEffect, Fragment } from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import Form from 'react-bootstrap/Form';
import {ToastContainer,toast} from "react-toastify"
import 'react-toastify/dist/ReactToastify.css';

const ExamView = () => {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const [exId, setExId] = useState("");
    const [examName, setExName] = useState("");
    const [examDate, setExDate] = useState("");
    const [className, setLExClName] = useState("");
    const [subjectName, setExSbName] = useState("");

    const [exEditId, setEditExId] = useState("");
    const [examEditName, setEditExname] = useState("");
    const [examEditDate, setEditExDate] = useState("");
    const [classEditName, setLEditExClname] = useState("");
    const [subjectEditName, setEditExSbname] = useState("");

    const [options, setOption] = useState([]);
    const [data, setdata] = useState([]);
    const [errors, setErrors] = useState({});

    useEffect(() => {
        if (sessionStorage.getItem("token") != null) {
            console.log(sessionStorage.getItem("token"));
            const headers = {
              Authorization: `Bearer ${sessionStorage.getItem("token")}`,
            };
        axios.get('http://localhost:5297/api/Examination/GetExamination',{headers})
            .then((result) => {
                setOption(result.data);
            })
            .catch((error) => {
                console.log(error);
                toast.error(error)
            });
        getData();
    }}, []);

    const getData = () => {
        if (sessionStorage.getItem("token") != null) {
            console.log(sessionStorage.getItem("token"));
            const headers = {
              Authorization: `Bearer ${sessionStorage.getItem("token")}`,
            };
        axios.get('http://localhost:5297/api/Examination/GetExamination',{headers})
            .then((result) => {
                setdata(result.data);
            })
            .catch((error) => {
                console.log(error);
                toast.error(error)
            });
    }};


    const handleUpdate = () => {
        if (sessionStorage.getItem("token") != null) {
            console.log(sessionStorage.getItem("token"));
            const headers = {
              Authorization: `Bearer ${sessionStorage.getItem("token")}`,
            };
        const url = 'http://localhost:5297/api/Examination/EditExam';
        const data = {
            examId: exEditId,
            examName: examEditName,
            examDate: examEditDate,
            classId: classEditName,
            subjectId: subjectEditName
        };

        axios.put(url, data,{headers})
            .then((result) => {
                handleClose();
                getData();
                toast.success("Exam is  has been updated")
            })
            .catch((error ) => {
                console.error(error);
                toast.error(error)
            });
    }};

    const handleSave = () => {
      const newErrors = {};
      
    
      
      const isDuplicateId = data.some(item => item.examId === exId);
      if (isDuplicateId) {
          newErrors.exId = "Exam ID already exists";
      } else if (!exId) {
          newErrors.exId = "Exam ID is required";
      } else {
          newErrors.exId = "";
      } 
      if (!examName) {
          newErrors.examName = "Exam Name is required";
      } else {
          newErrors.examName = "";
      }
      if (!examDate) {
          newErrors.examDate = "Exam Date is required";
      } else {
          newErrors.examDate = "";
      }
      if (!className) {
          newErrors.className = "Class Name is required";
      } else {
          newErrors.className = "";
      }
      if (!subjectName) {
          newErrors.subjectName = "Subject Name is required";
      } else {
          newErrors.subjectName = "";
      }
  
      setErrors(newErrors);
      
      if (Object.values(newErrors).every(error => !error)) {
        if (sessionStorage.getItem("token") != null) {
            console.log(sessionStorage.getItem("token"));
            const headers = {
              Authorization: `Bearer ${sessionStorage.getItem("token")}`,
            };
          const url = 'http://localhost:5297/api/Examination/AddExam';
          const data = {
              examId: exId,
              examName: examName,
              examDate: examDate,
              classId: className,
              subjectId: subjectName
          };
  
          axios.post(url, data,{headers})
              .then((result) => {
                  getData();
                  toast.success("Exam has been added");
                  clear(); 
              })
              .catch((error) => {
                  console.error(error);
                  toast.error(error)
              });
      }}
  };
  

  const handleExIdChange = (e) => {
    const inputValue = e.target.value;
    setExId(inputValue);
    const newErrors = { ...errors };

    if (!/^[a-zA-Z0-9]*$/.test(inputValue)) {
        newErrors.exId = "Exam ID should only contain alphanumeric characters";
    } else {
        newErrors.exId = "";
    }

    setErrors(newErrors);
};


const handleExamNameChange = (e) => {
  const inputValue = e.target.value;
  setExName(inputValue);
  const newErrors = { ...errors };

  if (!/^[a-zA-Z0-9]*$/.test(inputValue)) {
      newErrors.examName = "Exam Name should only contain alphanumeric characters";
  } else {
      newErrors.examName = "";
  }

  setErrors(newErrors);
};

const handleExamDateChange = (e) => {
  const selectedDate = new Date(e.target.value);
  const today = new Date();
  const newErrors = { ...errors };

  if (selectedDate < today) {
      newErrors.examDate = "Exam Date cannot be a past date";
  } else {
      newErrors.examDate = "";
      setExDate(e.target.value);
  }

  setErrors(newErrors);
};

const handleClassNameChange = (e) => {
    setLExClName(e.target.value);
    setErrors(prevErrors => ({ ...prevErrors, className: '' }));
};

const handleSubjectNameChange = (e) => {
    setExSbName(e.target.value);
    setErrors(prevErrors => ({ ...prevErrors, subjectName: '' }));
};

  
    const clear = () => {
        setExId('');
        setExName('');
        setExDate('');
        setLExClName('');
        setExSbName('');
        setEditExId('');
        setEditExname('');
        setEditExDate('');
        setLEditExClname('');
        setEditExSbname('');
        setErrors({});
    };

    return(
      <Fragment>
        

      <br />
      <div className='pt-2'>
          <Table striped bordered hover>
              <thead>
                  <tr>
                      <th>Index</th>
                      <th>Exam Id</th>
                      <th>Exam Name</th>
                      <th>Date of Examination</th>
                      <th>Class Name</th>
                      <th>Subject Name</th>

                  </tr>
              </thead>
              <tbody>
                  {
                      data && data.length > 0 ?
                          data.map((item, index) => {
                              return (
                                  <tr key={index}>
                                      <td>{index + 1}</td>
                                      <td>{item.examId}</td>
                                      <td>{item.examName}</td>
                                      <td>{item.examDate}</td>
                                      <td>{item.clsName}</td>
                                      <td>{item.subject}</td>
                                      {/* <td colSpan={2}>
                                   
                                      </td> */}
                                  </tr>
                              )
                          })
                          :
                          'Loading.......'
                  }
  
              </tbody>
          </Table>
      </div>
      <Modal show={show} onHide={handleClose}>
          <Modal.Header closeButton>
              <Modal.Title>Modify /Update Exam</Modal.Title>
          </Modal.Header>
          <Modal.Body>
              <Row>
                  <Col>
                      <input type="text" className='form-control' placeholder='Enter Exam Id'
                          value={exEditId} onChange={(e) => setEditExId(e.target.value)} />
                      <input type="text" className='form-control' placeholder='Enter sub id '
                          value={subjectEditName} onChange={(e) => setEditExSbname(e.target.value)} />
                  </Col>
              </Row>
              <Row className='pb-3'>
                  <Col>
                      <input type="text" className='form-control' placeholder='Enter  Exam Name'
                          value={examEditName} onChange={(e) => setEditExname(e.target.value)} />
                  </Col>
                  <Col>
                      <input type="date" className='form-control' placeholder='Enter Exam Date'
                          value={examEditDate} onChange={(e) => setEditExDate(e.target.value)} />
                  </Col>
                  <Col>
                      <input type="text" className='form-control' placeholder='Enter classId'
                          value={classEditName} onChange={(e) => setLEditExClname(e.target.value)} />
  
                  </Col>
              </Row>
          </Modal.Body>
          <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                  Close
              </Button>
              <Button variant="primary" onClick={handleUpdate}>
                  Save Changes
              </Button>
          </Modal.Footer>
      </Modal>
  </Fragment>
    )
}

export default ExamView;
