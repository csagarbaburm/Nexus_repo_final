import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import { useNavigate } from 'react-router-dom';
const StudentAttendanceReport =()=>{

    const [show, setShow] = useState(false);


    const [studentid,setStudentID] = useState("")

    let navigate=useNavigate();
    useEffect(()=>{
      if(sessionStorage.getItem("token")==null){
          navigate('/loginpages')
      }
  },[])
 
    

    const[fromday,setToday]=useState("");

    const [data,setdata] = useState([])

    useEffect(()=>{
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };}
        // setdata(stdData)
        getData(fromday)
    },[fromday])

    useEffect(()=>{
      // setdata(stdData)
      getData(fromday)
  },[studentid])


    const getData =(today)=>{
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
      axios.get(`http://localhost:5297/api/StudentAttendance/GetAttendReportof/${studentid}/${fromday}`,{headers})
      .then((result)=>{
        setdata([result.data])
        
        console.log(result.data);
      })
      .catch((error)=>{
        console.log(error);
      })
    }}


    
   

    return(
        <Fragment>
          <ToastContainer/>
          <Container>

     
        <Row className='pt-2'>

        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Student ID'
     onChange={(e)=> setStudentID(e.target.value)} />
        </Col>
        <Col>
        <input type="date" className='form-control form-control-sm' placeholder='Select date'
     onChange={(e)=> setToday(e.target.value)} />
        </Col>
        
        </Row>
        <Row className='pt-2'>
        <Col>
        {/* <button className='btn btn-primary '   onClick={()=>handleSave()}>Add Student</button> */}
      
        </Col>
      </Row>
     
    </Container>
    <br></br>
    <div className='pt-2' >
      <Table striped bordered hover >
      <thead>

        <tr>
          <th>index</th>
          <th>totalWorkingDays</th>
          <th>totalAttendance</th>
          <th>attendancePercentage</th>
        </tr>
      </thead>
      <tbody>
        {
          data && data.length > 0 ?
          data.map((item,index)=>{
            return (
              <tr key={index}>
              <td>{index+1}</td>
              <td>{item.totalWorkingDays}</td>
              <td>{item.totalAttendance}</td>
              <td>{item.attendancePercentage}</td>
            
            </tr>
            )
          })
          :
          'Loading.......'
        }
       
      </tbody>
    </Table>
    </div>
        </Fragment>
    )
}

export default StudentAttendanceReport;