import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
const TeacherAttendanceReport =()=>{

    const [show, setShow] = useState(false);


    const [teacherid,setTeacherId] = useState("")

 
    

    const[fromday,setToday]=useState("");

    const [data,setdata] = useState([])

    useEffect(()=>{
        // setdata(stdData)
        if (sessionStorage.getItem("token") != null) {
          console.log(sessionStorage.getItem("token"));
          const headers = {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          };}
        getData(fromday)
    },[fromday])

    useEffect(()=>{
      // setdata(stdData)
      getData(fromday)
  },[teacherid])


    const getData =(today)=>{
      axios.get(`http://localhost:5297/api/TeacherAttendance/GetAttendReportof/${sessionStorage.getItem("USERID")}/${fromday}`,{headers})
      .then((result)=>{
        setdata([result.data])
        console.log(result.data);
      })
      .catch((error)=>{
        console.log(error);
      })
    }



  
  
    
   

    return(
        <Fragment>
          <ToastContainer/>
          <Container>

     
        <Row className='pt-2'>

        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Teacher ID'
     onChange={(e)=> setTeacherId(e.target.value)} />
        </Col>
        <Col>
        <input type="date" className='form-control form-control-sm' placeholder='Select date'
     onChange={(e)=> setToday(e.target.value)} />
        </Col>
        
        </Row>
        <Row className='pt-2'>
        <Col>
        {/* <button className='btn btn-primary '   onClick={()=>handleSave()}>Add Student</button> */}
      
        </Col>
      </Row>
     
    </Container>
    <br></br>
    <div className='pt-2' >
      <Table striped bordered hover >
      <thead>

        <tr>
          <th>index</th>
          <th>totalWorkingDays</th>
          <th>totalAttendance</th>
          <th>attendancePercentage</th>
        </tr>
      </thead>
      <tbody>
        {
          data && data.length > 0 ?
          data.map((item,index)=>{
            return (
              <tr key={index}>
              <td>{index+1}</td>
              <td>{item.totalWorkingDays}</td>
              <td>{item.totalAttendance}</td>
              <td>{item.attendancePercentage}</td>
              


              {/* <td colSpan={2} style={{width:"auto"}}> */}
             {/* <input type='checkbox' onClick={(e)=>{ 
              handleUpdate(item)
                     
            }}></input> */}
              {/* </td> */}
            </tr>
            )
          })
          :
          'Loading.......'
        }
       
      </tbody>
    </Table>
    </div>
        </Fragment>
    )
}

export default TeacherAttendanceReport;