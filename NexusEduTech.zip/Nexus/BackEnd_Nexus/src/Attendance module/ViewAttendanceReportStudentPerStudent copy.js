import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import { useNavigate } from 'react-router-dom';
const StudentAttendanceReportperstudent =()=>{

let navigate=useNavigate();
useEffect(()=>{
  if(sessionStorage.getItem("token")==null){
      navigate('/loginpages')
  }
},[])
  const [studentid,setStudentID] = useState(sessionStorage.getItem("USERID"))
  const[fromday,setToday]=useState("");

  const [data,setdata] = useState([]);

  useEffect(()=>{
    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };

        getData(fromday)
    }},[fromday])



  const getData =(fromday)=>{
    console.log(studentid,fromday)
    console.log(sessionStorage.getItem("USERID"))
    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };
      axios.get(`http://localhost:5297/api/StudentAttendance/GetAttendReportof/${sessionStorage.getItem("USERID")}/${fromday}`,{headers})
      .then((result)=>{
        setdata([result.data])
        console.log(result.data);
      })
      .catch((error)=>{
        console.log(error);
      })
    }}


    return(
        <Fragment>
          <ToastContainer/>
          <Container>

     
        <Row className='pt-2'>
        <Col>
        <input type="date" className='form-control form-control-sm' placeholder='Select date'
          onChange={(e)=> setToday(e.target.value)} />
        </Col>
        
        </Row>
        <Row className='pt-2'>
        <Col>
        </Col>
      </Row>
     
    </Container>
    <br></br>
    <div className='pt-2' >
      <Table striped bordered hover >
      <thead>

        <tr>
          <th>index</th>
          <th>totalWorkingDays</th>
          <th>totalAttendance</th>
          <th>attendancePercentage</th>
        </tr>
      </thead>
      <tbody>
        {
          data && data.length > 0 ?
          data.map((item,index)=>{
            return (
              <tr key={index}>
              <td>{index+1}</td>
              <td>{item.totalWorkingDays}</td>
              <td>{item.totalAttendance}</td>
              <td>{item.attendancePercentage}</td>
              
            </tr>
            )
          })
          :
          'Loading.......'
        }
       
      </tbody>
    </Table>
    </div>
        </Fragment>
    )
}

export default StudentAttendanceReportperstudent;