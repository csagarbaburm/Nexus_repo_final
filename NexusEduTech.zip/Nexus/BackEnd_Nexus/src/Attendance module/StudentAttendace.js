import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import { useNavigate } from 'react-router-dom';
const StAttendance =()=>{
  let navigate=useNavigate();

  useEffect(()=>{
    if(sessionStorage.getItem("token")==null){
        navigate('/loginpages')
    }
},[])

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);

    const [status,setStatus] = useState("Absent")
    const [classname,setClass] = useState("")

    const[today,setToday]=useState("");

    const [data,setdata] = useState([])

    useEffect(()=>{

      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
      
      console.log(`Heeader: ${headers}`)
      }
        getData(today)
    },[today])

    useEffect(()=>{

      getData(today)
  },[classname])


    const getData =(today)=>{
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          "Authorization": `Bearer ${sessionStorage.getItem("token").trim()}`,
          "Content-Type": "application/json"
        };
        console.log(`http://localhost:5297/api/StudentAttendance/AddStudentAttendance/${today}/${classname}`,{ headers });
      axios.post(`http://localhost:5297/api/StudentAttendance/AddStudentAttendance/${today}/${classname}`,{},{ headers })
      .then((result)=>{
        setdata(result.data)
        
        console.log(result.data);
      })
      .catch((error)=>{
        console.log(error);
      })
    }}



    const handleUpdate = (item)=>{
     console.log("check");
     console.log(item.status=="Absent"?"Present":"Absent")
     const url ='http://localhost:5297/api/StudentAttendance/EditAttendance'
     const data = {
      "studentId": item.studentId,
      "studentname": item.studentname,
      "rollNO": item.rollNO,
      "date": item.date,
      "status":(item.status=="Absent"?"Present":"Absent"),
      "classname": item.classname
    }
    console.log(data);
    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };
    axios.put(url,data,{ headers })
    .then((result)=>{
      console.log("Entered into edit api");
      handleClose()
      getData(today);
      console.log(result.data);
      getData();
      // clear();
      toast.success("Student attendance has been updated")
    })
    .catch((error)=>{
      console.log(error)
    })
    }}
 
   

    return(
        <Fragment>
          <ToastContainer/>
          <Container>

     
        <Row className='pt-2'>


        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Class name'
     onChange={(e)=> setClass(e.target.value)} />
        </Col>
        <Col>
        <input type="date" className='form-control form-control-sm' placeholder='Select date'
     onChange={(e)=> setToday(e.target.value)} />
        </Col>
        
        </Row>
        <Row className='pt-2'>
        <Col>

      
        </Col>
      </Row>
     
    </Container>
    <br></br>
    <div className='pt-2' >
      <Table striped bordered hover >
      <thead>

        <tr>
          <th>index</th>
          <th>studentId</th>
          <th>RollNo</th>
          <th>FirstName</th>
          <th>Date</th>
          <th>Status</th>
          <th>ClassName</th>
        </tr>
      </thead>
      <tbody>
        {
          data && data.length > 0 ?
          data.map((item,index)=>{
            return (
              <tr key={index}>
              <td>{index+1}</td>
              <td>{item.studentId}</td>
              <td>{item.rollNO}</td>
              <td>{item.studentname}</td>
              <td>{item.date}</td>
              <td>{item.status}</td>

              <td>{item.classname}</td>
              
              <td colSpan={2} style={{width:"auto"}}>
             <input type='checkbox' onClick={(e)=>{ 
              handleUpdate(item)
                     
            }}></input>
              </td>
            </tr>
            )
          })
          :
          'Loading.......'
        }
       
      </tbody>
    </Table>
    </div>
 
        </Fragment>
    )
}

export default StAttendance;