import React, { useState ,useEffect} from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
 
const CId = () => {
  const [classId, setId] = useState("");
  const [studentDetails, setStudentDetails] = useState(""); // State variable to store teacher details
 const navigate=useNavigate();

  useEffect(() => {
    if (classId === "") {
      setStudentDetails("");
      return;
    } if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };}
    getByClass();
  }, [classId]);

  
  useEffect(()=>{
    if(sessionStorage.getItem("token")==null){
        navigate('/loginpages')
    }
})


  const getByClass = () => {
    if (sessionStorage.getItem("token") != null) {
      console.log(sessionStorage.getItem("token"));
      const headers = {
        Authorization: `Bearer ${sessionStorage.getItem("token")}`,
      };
    axios
      .get("http://localhost:5297/api/Student/GetStudentClass/" + classId,{headers})
      .then((response) => {
        console.log(response.data);
        setStudentDetails(response.data); // Update state with fetched teacher details
      })
      .catch((error) => console.log(error));
  }};
 
 
  return (
    <div className="container">
        <h1>Get Class By Name</h1>
        <br/>
      <div>
        <input
          type="text" className="form-control" placeholder="Enter class Name"
          value={classId}
          onChange={(e) => setId(e.target.value)}
        />
        <div className="pt-2">
        <button className="btn btn-primary" onClick={()=>getByClass()}>Get Student By Class Name</button>
        </div>
        <br/><br/>
      </div>
      {studentDetails && (
        <table className="table">
          <thead>
            <tr>
                <th>StudentId</th>
                <th>RollNO</th>
                <th>firstName</th>
                <th>lastName</th>
                <th>Email</th>
                <th>Date Of Birth</th>
                <th>Gender</th>
                <th>Section</th>
                <th>ClassName</th>
            </tr>
          </thead>
          <tbody>
          {studentDetails.map((student)=>{
    return(
        <tr>
            <td>{student.studentId}</td>
            <td>{student.rollNO}</td>
            <td>{student.firstName}</td>
            <td>{student.lastName}</td>
            <td>{student.email}</td>
            <td>{student.dob}</td>
            <td>{student.gender}</td>
            <td>{student.section}</td>
            <td>{student.cls}</td>
            </tr>
    )
})}
          </tbody>
        </table>
      )}
    </div>
  );
};
 
export default CId;