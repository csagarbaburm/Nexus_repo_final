import React, { useState,useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
 
const Roll = () => {
  const navigate=useNavigate();
    const [studentRoll, setRoll] = useState("");
    const [studentDetails, setStudentDetails] = useState(""); // State variable to store teacher details
  
    
    useEffect(()=>{
      if(sessionStorage.getItem("token")==null){
          navigate('/loginpages')
      }
  })
    useEffect(() => {
      if (studentRoll === "") {
        setStudentDetails("");
        return;
      }if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
      getByRoll();
      
    }else{navigate('/')}}, [studentRoll]);
  
    const getByRoll = () => {
      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
        console.log(headers)
      axios
      
        .get(`http://localhost:5297/api/Student/GetStudentRoll/${studentRoll}`,{headers})
        .then((response) => {
          console.log(response.data);
          setStudentDetails(response.data); // Update state with fetched teacher details
        })
        .catch((error) => console.log(error));
    }};
  
 
  return (
    
    <div className="container">
      <div>
        <input
          type="text" className="form-control" placeholder="Enter the StudentBy Roll"
          value={studentRoll}
          onChange={(e) => setRoll(e.target.value)}
        />
        <div className="pt-2">
        <button  className="btn btn-primary" onClick={()=>getByRoll()}>Get Student By RollNo</button>
        </div>
      </div>
      {studentDetails && (
        <table className="table">
          <tbody>
            <tr>
              <td>ID</td>
              <td>{studentDetails.studentId}</td>
            </tr>
            <tr>
              <td>RollNO</td>
              <td>{studentDetails.rollNO}</td>
            </tr>
            <tr>
              <td>First Name</td>
              <td>{studentDetails.firstName}</td>
            </tr>
            <tr>
              <td>Last Name</td>
              <td>{studentDetails.lastName}</td>
            </tr>
            <tr>
              <td>Email</td>
              <td>{studentDetails.email}</td>
            </tr>
            <tr>
              <td>Date of Birth</td>
              <td>{studentDetails.dob}</td>
            </tr>
            <tr>
              <td>Gender</td>
              <td>{studentDetails.gender}</td>
            </tr>
            <tr>
              <td>Section</td>
              <td>{studentDetails.section}</td>
            </tr>
            <tr>
              <td>Class</td>
              <td>{studentDetails.cls}</td>
            </tr>
          </tbody>
        </table>
      )}
    </div>
  );
};
 
export default Roll;
