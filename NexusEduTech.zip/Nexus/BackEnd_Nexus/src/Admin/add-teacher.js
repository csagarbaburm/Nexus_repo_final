import React from "react";

export default function AddTeacher() {
  return <div>add-teacher</div>;
}
