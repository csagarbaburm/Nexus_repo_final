import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
const CRUD =()=>{

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const [id,setId] = useState("")
    const [rollno,setRoll] = useState("")
    const [firstname,setFname] = useState("")
    const [lastName,setLname] = useState("")
    const [userName,setUname] = useState("")
    const [email,setEmail] = useState("")
    const [gender,setGender] = useState("")
    const [dob,setDob] = useState("")
    const [mobilenum,setMobilenum] = useState("")
    const [classId,setClass] = useState("")

    const [editrollno,setEditRoll] = useState("")
    const [editfirstname,setEditFname] = useState("")
    const [editlastName,setEditLname] = useState("")
    const [edituserName,setEditUname] = useState("")
    const [editemail,setEditEmail] = useState("")
    const [editgender,setEditGender] = useState("")
    const [editdob,setEditDob] = useState("")
    const [editmobilenum,seteditMobilenum] = useState("")
    const [editclassId,setEditClass] = useState("")
    const [editstdId,setEditStdId] = useState("")

 

    // const stdData = [
    //     {
    //         id:1,
    //         name:"faris",
    //         age:23,
    //         isActive:1
    //     },
    //     {
    //         id:2,
    //         name:"amal",
    //         age:32,
    //         isActive:0
    //     },
    //     {
    //         id:3,
    //         name:"sajjad",
    //         age:34,
    //         isActive:1
    //     },
    // ]

    const [data,setdata] = useState([])

    useEffect(()=>{
        // setdata(stdData)
        getData()
    },[])

    const getData =()=>{
      axios.get('http://localhost:5297/api/Student/GetAllStudent')
      .then((result)=>{
        setdata(result.data)
        console.log(result.data);
      })
      .catch((error)=>{
        console.log(error);
      })
    }

    const handleEdit =(studentId)=>{
       handleShow();
       axios.get(`http://localhost:5297/api/Student/GetStudentId/${studentId}`)
       .then((result)=>{
    
        setEditFname(result.data.firstName)
        setEditLname(result.data.lastName)
        setEditEmail(result.data.email)
        setEditGender(result.data.gender)
        setEditRoll(result.data.rollNO)
        setEditStdId(result.data.studentId)
        setEditDob(result.data.dob)
        setEditClass(result.data.cls)
       })
       .catch((error)=>{
        toast.error(error)
       })
    }

    const handleDelete =(studentId)=>
    {
      if(window.confirm("Are you sure to delete this Student") === true){
        console.log(studentId)
        axios.delete(`http://localhost:5297/api/Student/DeleteStudent/${studentId}`)
        .then((result)=>{
          if(result.status === 200)
          {
            toast.success("Deleted succesfully")
            getData();
          }
          
        })
        .catch((error)=>{
          toast.error(error)
        })
      }
     
    }


    const handleUpdate = ()=>{
     console.log("check");
     const url ='http://localhost:5297/api/Student/EditStudent'
     const data = {
      "studentId": editstdId,
      "firstName": editfirstname,
      "lastName": editlastName,
      "rollNO": editrollno,
      "dob": editdob,
      "gender": editgender,
      "email": editemail,
      "mobileNum": mobilenum,
      "classId": editclassId
    }
    console.log(data);
    
    axios.put(url,data)
    .then((result)=>{
      console.log("Entered into edit api");
      handleClose()
      console.log(result.data);
      getData();
      // clear();
      toast.success("Student has been updated")
    })
    .catch((error)=>{
      console.log(error)
    })
    }
    //
    // const handleActiveChange =(e)=>{
    //   if(e.target.checked){
    //     setActive(1)
    //   }
    //   else{
    //     setActive(0)
    //   }
    // }
    //break
    // const handleEditActiveChange =(e)=>{
    //   if(e.target.checked){
    //     setEditActive(1)
    //   }
    //   else{
    //     setEditActive(0)
    //   }
    // }

    //needed data
    const handleSave =() =>{
      const url ='http://localhost:5297/api/Student/AddStudent'
      const data = {
        "studentId": id,
        "firstName": firstname,
        "lastName": lastName,
        "rollNO": rollno,
        "dob": dob,
        "gender": gender,
        "email": email,
        "mobileNum": mobilenum,
        "classId": classId
      }
      axios.post(url,data)
      .then((result)=>{
        console.log(result.data);
        getData();
        clear();
        toast.success("Student has been added")
      })
      .catch((error)=>{
        toast.error(error)
      })
    }
    
    const clear = ()=>{
      setFname('')
      setLname('')
      setGender("")
      setDob('')
      setRoll('')
      setEmail("")
      setClass('')
      setEditFname('')
      setEditLname('')
      setEditEmail('')
      setEditGender('')
      setEditRoll('')
      setEditStdId('')
      setEditDob('')
      setEditClass('')
    }

    return(
        <Fragment>
          <ToastContainer/>
          <Container>
            <Row>
            <Col>
          <input type="text" className='form-control form-control-sm' placeholder='Enter StudentId '
           value={id} onChange={(e)=> setId(e.target.value)} />
          </Col>
           <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter Roll '
        value={rollno} onChange={(e)=> setRoll(e.target.value)} />
        </Col>
      
            </Row>
      <Row className='pt-2'>
      <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter FirstName'
        value={firstname} onChange={(e)=> setFname(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter LastName'
        value={lastName} onChange={(e)=> setLname(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter Gender'
        value={gender} onChange={(e)=> setGender(e.target.value)} />
        </Col>
        </Row>
        <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter Email'
        value={email} onChange={(e)=> setEmail(e.target.value)} />
        </Col>
        <Col>
        <input type="date" className='form-control form-control-sm' placeholder='Enter Dob'
        value={dob} onChange={(e)=> setDob(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter ClassName'
        value={classId} onChange={(e)=> setClass(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter MobileNumber'
        value={mobilenum} onChange={(e)=> setMobilenum(e.target.value)} />
        </Col>
        
        </Row>
        <Row className='pt-2'>
        <Col>
        <button className='btn btn-primary '   onClick={()=>handleSave()}>Add Student</button>
      
        </Col>
      </Row>
     
    </Container>
    <br></br>
    <div className='pt-2' >
      <Table striped bordered hover >
      <thead>
        <tr>
          <th>index</th>
          <th>studentId</th>
          <th>RollNo</th>
          <th>FirstName</th>
          <th>LastName</th>
          <th>Email</th>
          <th>Gender</th>
          <th>DOB</th>
          <th>ClassName</th>
          <th>Section</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {
          data && data.length > 0 ?
          data.map((item,index)=>{
            return (
              <tr key={index}>
              <td>{index+1}</td>
              <td>{item.studentId}</td>
              <td>{item.rollNO}</td>
              <td>{item.firstName}</td>
              <td>{item.lastName}</td>
              <td>{item.email}</td>
              <td>{item.gender}</td>
              <td>{item.dob}</td>
              <td>{item.cls}</td>
              <td>{item.section}</td>
              
              <td colSpan={2} style={{width:"auto"}}>
             
              
                <button className='btn btn-primary'  onClick={()=>handleEdit(item.studentId)} >Edit</button> &nbsp;
                <button className='btn btn-danger' onClick={()=> handleDelete(item.studentId)}  >Delete</button>
              </td>
            </tr>
            )
          })
          :
          'Loading.......'
        }
       
      </tbody>
    </Table>
    </div>
    <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modify /Update employe</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Row>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Roll'
        value={editrollno} onChange={(e)=> setEditRoll(e.target.value)} />
        </Col>
        </Row>
        <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='Enter firstname'
        value={editfirstname} onChange={(e)=> setEditFname(e.target.value)} />
        </Col>
      </Row>
      <Row>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Lastname'
        value={editlastName} onChange={(e)=> setEditLname(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Email'
        value={editemail} onChange={(e)=> setEditEmail(e.target.value)} />
        </Col>
      </Row>
      <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Gender'
        value={editgender} onChange={(e)=> setEditGender(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Dob '
        value={editdob} onChange={(e)=> setEditDob(e.target.value)} />
        </Col>
        </Row>
        <Row>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Mobile number'
        value={editmobilenum} onChange={(e)=> seteditMobilenum(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Enter classId'
        value={editclassId} onChange={(e)=> setEditClass(e.target.value)} />
        </Col>
      </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleUpdate}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
        </Fragment>
    )
}

export default CRUD;