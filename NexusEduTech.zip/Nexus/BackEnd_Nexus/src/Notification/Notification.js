import React, { useEffect, useState } from "react";
import styles from "./Notification.module.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
// import '../../node_modules/bootstrap/dist/css/bootstrap.min.css';
 
const Notification = () => {

  const [message, setMessage] = useState("");
  const [date, setDate] = useState("");
  const [role, setRole] = useState("");
  let navigate=useNavigate();
    
  useEffect(() => {

      if(sessionStorage.getItem("token")==null){
          navigate('/loginpages')
      }

  
    }, []);
 
  const validateForm = () => {
    return  message.length > 0 && date.length > 0 && role.length > 0;
  }
 
  const Save = (e) => {
    e.preventDefault();
    if (validateForm()) {
      let notification = {

        message: message,
        date: date,
        role: role
      };

      if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
    
      axios
        .post("http://localhost:5297/api/Notification/AddNotification", notification,{headers})
        .then((response) => {
          console.log(response.data);
          alert("Notification send sucessfully")
        })
        .catch((error) => console.log(error));
    } }else {
      alert("Please fill in all fields");
    }
  };
 
  return (
    <div className={styles.emailform}>
      <h1>Send a Notification </h1>
 
      <form onSubmit={Save}>
        {/* <label htmlFor="email">NotificationId</label>
        <input
          value={notificationId}
          onChange={(e) => setId(e.target.value)}
        /> */}
        <label htmlFor="message">Message</label>
        <textarea
          placeholder="Enter your message here..."
          value={message}
          name="message"
          onChange={(e) => setMessage(e.target.value)}
        />
        <label htmlFor="date" spacing={4}> Date</label>
        <input type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        <div value={role}>
          <h5>Select Recipients   </h5>
          <label className={styles.container1}>Teachers
            <input type="checkbox" value="teacher" onChange={(e) => setRole(e.target.value)} />
            <span className={styles.checkmark}></span>
          </label>
          <label className={styles.container1}>Students
            <input type="checkbox" value="students" onChange={(e) => setRole(e.target.value)} />
            <span className={styles.checkmark}></span>
          </label>
        
        </div>
        <button type="submit" disabled={!validateForm()}>
          Send Notification
        </button>
      </form>
    </div>
  );
};
 
export default Notification;