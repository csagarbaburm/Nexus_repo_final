import axios from 'axios'
import React,{useEffect,useState} from 'react'
import { useNavigate } from 'react-router-dom'

export default function StudentNotification() {
    const [notification, setNotification] = useState([])
    let navigate=useNavigate();
    useEffect(() => {
              if (sessionStorage.getItem("token") != null) {
        console.log(sessionStorage.getItem("token"));
        const headers = {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        };
    
     axios
     .get("http://localhost:5297/api/Notification/GetNotification",{headers})
     .then((response)=> { 
        const allUserNotifications = response.data.filter(notification => notification.role !== "teacher");
        console.log(allUserNotifications);
        setNotification(allUserNotifications)
     }
        
     )
    }

        if(sessionStorage.getItem("token")==null){
            navigate('/loginpages')
        }
    }
    , [])
    
  return (
    <div className="main-content position-relative max-height-vh-100 h-100 border-radius-lg">
        <table className="table table-striped text-center">
            <thead>
                <tr>
                    <th><b>Date</b></th>
                    <th><b>Message</b></th>
                </tr>
            </thead>
            <tbody>
                {
                    notification.map((item)=>{
                        return(
                            <tr>
                                <td>{item.date}</td>
                                <td>{item.message}</td>

                            </tr>
                        )
                    })
                }
            </tbody>
        </table>
    </div>
  )
}
