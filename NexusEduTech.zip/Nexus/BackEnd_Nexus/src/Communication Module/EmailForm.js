import React, { useEffect, useRef, useState } from 'react';
import emailjs from '@emailjs/browser';
import styles from './EmailForm.module.css'
import { useNavigate } from 'react-router-dom';

export const ContactUs = () => {
  const form = useRef();
  const [toEmails, setToEmails] = useState('');
  const [ccEmails, setCcEmails] = useState('');

let navigate=useNavigate();
useEffect(()=>{
  if(sessionStorage.getItem("token")==null){
      navigate('/loginpages')
  }
},[])


  const sendEmail = (e) => {
    e.preventDefault();

    emailjs
      .sendForm('service_a9u8cnj', 'template_zsaigs6', form.current, {
        publicKey: 'x7qGcImS7gjBRMZPK',
        to: toEmails,
        cc: ccEmails 
      })
      .then(
        () => {
          console.log('SUCCESS!');
          alert("Email Send Sucessfully..!")
        },
        (error) => {
          console.log('FAILED...', error.text);
        },
      );
  };

  return (
    <div className="form-container">
      <form ref={form} onSubmit={sendEmail} className={styles.email-form}>
        <h2 className={styles.formheading}>Send Message</h2>
        <label className={styles.label}>Name</label>
        <input type="text" name="name" className={styles.inputfield} />
        {/* <label className="label">Email</label>
        <input type="email" name="email" className="input-field" /> */}
        <label className="label">Email To</label>
        <input
          type="text"
          name="to"
          className={styles.inputfield}
          value={toEmails}
          onChange={(e) => setToEmails(e.target.value)}
          placeholder="Enter multiple email addresses separated by commas"
        />
        <label className={styles.label}>CC (Multiple emails separated by commas)</label>
        <input
          type="text"
          name="cc"
          className={styles.inputfield}
          value={ccEmails}
          onChange={(e) => setCcEmails(e.target.value)}
          placeholder="Enter multiple email addresses separated by commas"
        />
        <label className="label">Message</label>
        <textarea name="message" className={styles.textareafield} />
        <input type="submit" value="Send" className={styles.submitbtn} />
      </form>
    </div>
  );
};
