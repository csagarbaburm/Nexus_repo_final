﻿using AutoMapper;
//using NexusProjectIntegration.DTOs;
using NexusProjectIntegration.Entity;
using Schedule__Class.DTO_s;
using SchoolManagementApi.DTOs;
//using Schedule__Class.DTO_s;
//using Schedule__Class.Entities;
namespace Schedule__Class.Profiles
{
    public class ScheduleClassProfile:Profile
    {
        public ScheduleClassProfile() 
        {
            CreateMap<ScheduleClass, ClassDto>();
            CreateMap<ClassAdd, ScheduleClass>();
            CreateMap<ScheduleClass,ClassDto>();
            CreateMap<ScheduleClass,ClassTeacherDto>();
            CreateMap<ScheduleClass,TeacherDTO>();
        }
    }
}
