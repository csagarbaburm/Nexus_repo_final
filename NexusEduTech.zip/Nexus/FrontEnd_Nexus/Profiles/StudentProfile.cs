﻿using SchoolManagementApi.DTO_s;
using AutoMapper;
using SchoolManagementApi.Entity;
namespace SchoolManagementApi.Profiles
{
    public class StudentProfile:Profile
    {
         public StudentProfile()
        {
            //CreateMap<StudentDto, Students>();
            CreateMap<Students, StudentDto>();
            CreateMap<StudentAddDto, Students>();
            //CreateMap<Students, StudentAddDto>();
        
        }
    
    }
}
