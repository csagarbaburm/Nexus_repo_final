﻿using AutoMapper;
using NexusProjectIntegration.Entity;
using SchoolManagementApi.DTO;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Profiles
{
    public class TeacherAttendanceProfile:Profile
    {
        public TeacherAttendanceProfile()
        {
            CreateMap<TeacherAttendanceAddDto, TeacherAttendance>();
            CreateMap<TeacherAttendance, TeacherAttendanceDto>();
        }
    }
}
