﻿using AutoMapper;
using SchoolManagementApi.DTOs;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Profiles
{
    public class TeacherProfile:Profile
    {
        public TeacherProfile() 
        {
            CreateMap<TeacherDTO, Teachers>();
            CreateMap<Teachers, TeacherDTO>();
            CreateMap<Teachers, TeacherDToadd>();
            CreateMap<TeacherDToadd, Teachers>();

        }
    }
}
