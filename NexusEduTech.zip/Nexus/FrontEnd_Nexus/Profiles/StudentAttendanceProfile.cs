﻿using AutoMapper;
using SchoolManagementApi.DTO;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Profiles
{
    public class StudentAttendanceProfile:Profile
    {
        public StudentAttendanceProfile()
        {
            CreateMap<StudentAttendanceAddDto, StudentAttendance>();
            CreateMap<StudentAttendance, StudentAttendanceDto>();
        }
    }
}
