﻿using AutoMapper;
using SchoolManagementApi.DTO;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Profiles
{
    public class ExamProfile:Profile
    {
           
        public ExamProfile()
        {
            CreateMap<Examinations, Examinationdto>();
            CreateMap<ExaminationAddDto, Examinations>();


        }
    }
}
