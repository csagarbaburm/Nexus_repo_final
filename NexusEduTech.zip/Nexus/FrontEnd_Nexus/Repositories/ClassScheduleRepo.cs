﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Schedule__Class.DTO_s;
using NexusProjectIntegration.Entity;
using System;
using SchoolManagementApi.Entity;
using NexusProjectIntegration.DTO_s;

namespace NexusProjectIntegration.Repository
{
    public class ClassScheduleRepo : IClassSchedule
    {
        private readonly MyContext context1;
        private readonly IMapper mapper;

        public ClassScheduleRepo(MyContext context,IMapper mapper)
        {
            context1 = context;
            this.mapper = mapper;
        }
        public void Add(ClassAdd cls)
        {
            try
            {
                ScheduleClass cls1 = mapper.Map<ScheduleClass>(cls);
                context1.Schedules.Add(cls1);
                context1.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<ClassDto> GetAll()
        {
            try
            {
                List<ScheduleClass> cls = context1.Schedules.ToList();
                List<ClassDto> classDto = mapper.Map<List<ClassDto>>(cls);

                int i = 0;

                foreach (var s in classDto)
                {

                    s.ClassName = (from c in context1.Classes
                                   where c.ClassId == cls[i].ClassId
                                   select c.Name).Single();
                    s.TeachName = (from c in context1.Teachers
                                   where c.TeacherId == cls[i].TeacId
                                   select c.FirstName).Single();

                    s.SubName = (from c in context1.Subjects
                                 where c.SubId == cls[i].SubjId
                                 select c.SubName).Single();
                    i++;
                }


                return (classDto);
            }
            catch (Exception)
            {

                throw;
            }

        }

        public List<ClassTeacherDto> GetClassByClassID(string classId)
        {
            try
            {
                List<ScheduleClass> cls = context1.Schedules.ToList();

                List<ScheduleClass> scheduleClasses = (from s in cls where s.ClassId == classId select s).ToList();



                List<ClassTeacherDto> classDto = mapper.Map<List<ClassTeacherDto>>(scheduleClasses);
                int i = 0;
                foreach (var s in classDto)
                {
                    s.TeachName = (from c in context1.Teachers
                                   where c.TeacherId == scheduleClasses[i].TeacId
                                   select c.FirstName).Single();
                    s.SubName = (from c in context1.Subjects
                                 where c.SubId == scheduleClasses[i].SubjId
                                 select c.SubName).Single();
                    i++;
                }



                return (classDto);
            }
            catch (Exception)
            {

                throw;
            }
        }
  
        public List<ClassDto> GetClassByTeacherID(string teacherId)
        {
            try
            {

                List<ScheduleClass> cls = context1.Schedules.ToList();
                List<ScheduleClass> schedules = (from s in cls where s.TeacId == teacherId select s).ToList();
                List<ClassDto> teacherDto = mapper.Map<List<ClassDto>>(schedules);
                int i = 0;
                foreach (var s in teacherDto)
                {
                    s.ClassName = (from k in context1.Classes
                                   where k.ClassId == schedules[i].ClassId
                                   select k.Name).Single(); i++;

                }
                i = 0;
                foreach (var s in teacherDto)
                {
                    s.SubName = (from k in context1.Subjects
                                 where k.SubId == schedules[i].SubjId
                                 select k.SubName).Single();
                    i++;

                }
                i = 0;
                foreach (var s in teacherDto)
                {


                    s.TeachName = (from c in context1.Teachers
                                   where c.TeacherId == schedules[i].TeacId
                                   select c.FirstName).Single();
                    i++;
                }

                return (teacherDto);

            }
            catch (Exception)
            {

                throw;
            }

        }

        public ClassDto GetScheduleById(string id)
        {
            try
            {
                ScheduleClass schedule = context1.Schedules.Find(id);

                ClassDto cls = mapper.Map<ClassDto>(schedule);

                int i = 0;


                cls.ClassName = (from c in context1.Classes
                                 where c.ClassId == schedule.ClassId
                                 select c.Name).Single();
                cls.TeachName = (from c in context1.Teachers
                                 where c.TeacherId == schedule.TeacId
                                 select c.FirstName).Single();

                cls.SubName = (from c in context1.Subjects
                               where c.SubId == schedule.SubjId
                               select c.SubName).Single();

                return (cls);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void Update(ClassAdd cls)
        {
            try
            {
                ScheduleClass cls1 = mapper.Map<ScheduleClass>(cls);
                context1.Schedules.Update(cls1);
                context1.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        //List<TeacherDto> IClassSchedule.GetClassByTeacherID(string teacherId)
        //{
        //    throw new NotImplementedException();
        //}

    
    }
}
