﻿using NexusProjectIntegration.Models;
using SchoolManagementApi.DTO;

namespace NexusProjectIntegration.Repositories
{
    public interface ITeacherAttendanceRepsitory
    {
        List<TeacherAttendanceDto> AddAttendance(DateTime today);
        AttendanceModel GetAllAttendancesByID(string id);
        AttendanceModel GetAttendanceFromDate(string id, DateTime date);
        TeacherAttendanceDto EditAttendance(TeacherAttendanceDto attendance);
    }
}
