﻿using NexusProjectIntegration.Entity;
using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repositories
{
    public class StudentRegisterRepository
    {
        private readonly MyContext context;

        public StudentRegisterRepository(MyContext context)
        {
            this.context = context;
        }

        public void AddID(StudentRegister id)
        {
            try
            {

                context.StudentRegisters.Add(id);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        public void DeleteID(string id)
        {
            try
            {
                StudentRegister st = context.StudentRegisters.Find(id);
                context.StudentRegisters.Remove(st);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        public List<StudentRegister> GetAll()
        {
            try
            {
                return (context.StudentRegisters.ToList());
            }
            catch (Exception)
            {

                throw;
            }
        }
        public StudentRegister GetById(string id)
        {
            try
            {
                return (context.StudentRegisters.Find(id));
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
