﻿using NexusProjectIntegration.Entity;
using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repositories
{
    public class TeacherRegisterRepository
    {
        private readonly MyContext context;

        public TeacherRegisterRepository(MyContext context)
        {
            this.context = context;
        }

        public void AddID(TeacherRegister id)
        {
            try
            {
                context.TeacherRegisters.Add(id);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        public void DeleteID(string id)
        {
            try
            {
                TeacherRegister st = context.TeacherRegisters.Find(id);
                context.TeacherRegisters.Remove(st);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        public List<TeacherRegister> GetAll()
        {
            try
            {
                return (context.TeacherRegisters.ToList());
            }
            catch (Exception)
            {

                throw;
            }
        }
        public TeacherRegister GetById(string id)
        {
            try
            {
                return (context.TeacherRegisters.Find(id));
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
