﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using NexusProjectIntegration.DTO_s;
using NexusProjectIntegration.Entity;
using NexusProjectIntegration.Models;
using NexusProjectIntegration.Repositories;
using SchoolManagementApi.DTO;
using SchoolManagementApi.Entity;


namespace NexusProjectIntegration.Repository
{
    public class TeacherAttendanceRepository : ITeacherAttendanceRepsitory
    {
        private readonly MyContext mycontext;
        private readonly IMapper mapper;

        public TeacherAttendanceRepository(MyContext context, IMapper mapper)
        {
            mycontext = context;
            this.mapper = mapper;
        }

        public List<TeacherAttendanceDto> AddAttendance(DateTime today)
        {
            try
            {

                List<TeacherAttendance> TE = (mycontext.TeacherAttendance.Where(s => today == s.Date).ToList());

                TeacherAttendance tchs = new TeacherAttendance();

                List<Teachers> t = mycontext.Teachers.ToList();

                if (TE.Count() == 0)

                {

                    foreach (Teachers tt in t)

                    {

                        //Random rnd = new Random();

                        tchs.TeacherId = tt.TeacherId;
                        Console.WriteLine(tchs.TeacherId);
                        tchs.Date = today;

                        tchs.AttendanceId = Guid.NewGuid().ToString();
                        tchs.Status = "Absent";

                        mycontext.TeacherAttendance.Add(tchs);

                        mycontext.SaveChanges();

                    }

                    //_context.StudAttendences.Add(sts);

                    //_context.SaveChanges();
                    List<TeacherAttendanceDto> tchAttlist = mapper.Map<List<TeacherAttendanceDto>>((mycontext.TeacherAttendance.Where(s => today == s.Date).ToList()));



                       return GetAttendanceOfDate(today);
                   // return tchAttlist;
                }
                else
                {

                  //  List<TeacherAttendanceDto> tchAttlist1 = mapper.Map<List<TeacherAttendanceDto>>((mycontext.TeacherAttendance.Where(s => today == s.Date).ToList()));
                    return GetAttendanceOfDate(today);
                }

            }

            catch (Exception ex)

            {

                throw ex;

            }

        }

        public List<TeacherAttendanceDto> GetAttendanceOfDate(DateTime today)
        {
            try
            {

                List<Teachers> alltchrs = mycontext.Teachers.ToList();

                List<TeacherAttendanceDto> tchAttlist = mapper.Map<List<TeacherAttendanceDto>>((mycontext.TeacherAttendance.Where(s => today == s.Date).ToList()));

                int i = 0;
                foreach (TeacherAttendanceDto t in tchAttlist)
                {

                    //t.TeachId = alltchrs[i].TeacherId;
                    t.Date = today;
                    t.TeacherName = (from tt in mycontext.Teachers
                                     where tt.TeacherId == t.TeacherId
                                     select tt.FirstName + " " + tt.LastName).SingleOrDefault();
                    i++;
                }

                return tchAttlist;

            }
            catch (Exception)
            {

                throw;
            }
        }



        public AttendanceModel GetAllAttendancesByID(string id)
        {
            try
            {
                List<TeacherAttendance> teacherAttendances = mycontext.TeacherAttendance.ToList();

                var attList = (from s in teacherAttendances
                               where s.TeacherId == id
                               select s).ToList();
                AttendanceModel att = new AttendanceModel();
                float TotalWorkingDays = attList.Count();

                float TotalAttendance = attList.Where(a => a.Status == "Present").Count();

                float AttendancePercentage = (TotalAttendance / TotalWorkingDays) * 100;
                att.TotalAttendance = TotalAttendance.ToString();
                att.TotalWorkingDays = TotalWorkingDays.ToString();
                att.AttendancePercentage = AttendancePercentage.ToString() + '%';

                //List<StudentAttendanceDto> stAttlist= mapper.Map<List<StudentAttendanceDto>>(attList);

                return (att);

            }
            catch (Exception)
            {

                throw;
            }
        }
        public TeacherAttendanceDto EditAttendance(TeacherAttendanceDto teacherAttendance)
        {
            try
            {

                //TeacherAttendance teacherAttendance = mapper.Map<TeacherAttendance>(attendance);

                TeacherAttendance ut = mycontext.TeacherAttendance.Where(t => t.TeacherId == teacherAttendance.TeacherId && t.Date == teacherAttendance.Date).SingleOrDefault();
                ut.Status = teacherAttendance.Status;

                mycontext.TeacherAttendance.Update(ut);
                mycontext.SaveChanges();
                return null;
            }
            catch (Exception)
            {

                throw;
            }
        }


        public AttendanceModel GetAttendanceFromDate(string id, DateTime date)
        {
            try
            {
                List<TeacherAttendance> studentAttendances = mycontext.TeacherAttendance.ToList();

                var attList = (from s in studentAttendances
                               where s.TeacherId == id && s.Date.Date >= date.Date
                               select s).ToList();
                AttendanceModel att = new AttendanceModel();
                float TotalWorkingDays = attList.Count();

                float TotalAttendance = attList.Where(a => a.Status == "Present").Count();

                float AttendancePercentage = (TotalAttendance / TotalWorkingDays) * 100;
                att.TotalAttendance = TotalAttendance.ToString();
                att.TotalWorkingDays = TotalWorkingDays.ToString();
                att.AttendancePercentage = AttendancePercentage.ToString() + '%';

                //List<StudentAttendanceDto> stAttlist= mapper.Map<List<StudentAttendanceDto>>(attList);

                return (att);

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
