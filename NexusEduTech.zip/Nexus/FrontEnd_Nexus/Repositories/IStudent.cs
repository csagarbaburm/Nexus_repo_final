﻿using SchoolManagementApi.DTO_s;
using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repository
{
    public interface IStudent
    {
        void Add(Students student);
        void Update(Students student);
        void Delete(string id);
        List<StudentDto> GetAll();
        StudentDto GetStudentById(string id);
        StudentDto GetStudentByRoll(string rollno);
        List<StudentDto> GetStudentByClass(string cls);
        List<StudentDto> GetStudentByClassandSec(string cls, string sec);

    }
}


//void Add(Teacher teacher);
//void Update(Teacher teacher);
//void Delete(int id);
//Teacher GetTeacher(int id);
//List<Teacher> GetAll();
//List<Teacher> GetTeachersBySubject(string subject);