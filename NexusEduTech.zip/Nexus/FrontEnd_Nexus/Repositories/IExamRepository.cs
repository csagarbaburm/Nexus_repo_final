﻿using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repository
{
    public interface IExamRepository
    {
        void AddExam(Examinations exam);
    }
}
