﻿namespace NexusProjectIntegration.Repositories
{
    public interface IPasswordRecovery
    {

        void Recovey(string username,string password);

        string Verify(string meail, string username);

    }
}
