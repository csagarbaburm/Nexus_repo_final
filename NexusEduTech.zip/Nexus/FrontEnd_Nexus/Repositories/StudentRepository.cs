﻿using AutoMapper;
using SchoolManagementApi.DTO_s;
using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repository
{
    public class StudentRepository : IStudent
    {
        private readonly MyContext _context;
        private readonly IMapper mapper;

        public StudentRepository(MyContext context,IMapper mapper)
        {
            _context = context;
            this.mapper = mapper;
        }
        public void Add(Students student)
        {

            try
            {
                _context.Students.Add(student);
                _context.SaveChanges();

            }
            catch (Exception)
            {

                throw;
            }
        }

        public void Delete(string id)
        {
            try
            {
                Students student = _context.Students.Find(id);
                _context.Students.Remove(student);
                _context.SaveChanges();

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<StudentDto> GetAll()
        {
            try
            {
                List<Students> student = _context.Students.ToList();
                List<StudentDto> studentDto = mapper.Map<List<StudentDto>>(student);
                int i = 0;
                foreach (var s in studentDto)
                {

                    s.Cls = (from c in _context.Classes
                             where c.ClassId == student[i].ClassId
                             select c.Name).Single();

                    s.Section = (from c in _context.Classes
                                 where c.ClassId == student[i].ClassId
                                 select c.Section).Single();

                    i++;
                }

                return (studentDto);

            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<StudentDto> GetStudentByClass(string cls)
        {
            try
            {
                //List<Students> students = (from s in _context.Students
                //                          join c in _context.Classes
                //                          on s.ClassId equals c.ClassId
                //                          where c.Name == cls 
                //                          select c).ToList();
                List<Students> student = _context.Students.Where(S => S.Cls.Name == cls).ToList();
                List<StudentDto> studentDto = mapper.Map<List<StudentDto>>(student);

                int i = 0;
                foreach (var s in studentDto)
                {
                    s.Cls = (from c in _context.Classes
                             where c.ClassId == student[i].ClassId
                             select c.Name).Single();
                    s.Section = (from c in _context.Classes
                                 where c.ClassId == student[i].ClassId
                                 select c.Section).Single();
                    i++;
                }

                return (studentDto);
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public List<StudentDto> GetStudentByClassandSec(string cls, string sec)
        {
            try
            {
                List<Students> student = _context.Students.Where(s => s.Cls.Name == cls && s.Cls.Section == sec).ToList();
                List<StudentDto> studentDto = mapper.Map<List<StudentDto>>(student);
                int i = 0;
                foreach (var s in studentDto)
                {

                    s.Cls = (from c in _context.Classes
                             where c.ClassId == student[i].ClassId
                             select c.Name).Single();

                    s.Section = (from c in _context.Classes
                                 where c.ClassId == student[i].ClassId
                                 select c.Section).Single();
                    i++;
                }

                return (studentDto);
            }
            catch (Exception)
            {

                throw;
            }
        }
        public StudentDto GetStudentByRoll(string rollno)
        {
            try
            {
                Students student = _context.Students.Where(e => e.RollNO == rollno).Single();
                StudentDto sdto = mapper.Map<StudentDto>(student);
                sdto.Cls = (from c in _context.Classes
                            where c.ClassId == student.ClassId
                            select c.Name).Single();

                sdto.Section = (from c in _context.Classes
                                where c.ClassId == student.ClassId
                                select c.Section).Single();


                return (sdto);
                //return student;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public StudentDto GetStudentById(string id)
        {
            try
            {
                Students student = _context.Students.Find(id);
                StudentDto sdto = mapper.Map<StudentDto>(student);
                sdto.Cls = (from c in _context.Classes
                            where c.ClassId == student.ClassId
                            select c.Name).Single();

                sdto.Section = (from c in _context.Classes
                                where c.ClassId == student.ClassId
                                select c.Section).Single();


                return (sdto);
                //return student;
            }
            catch (Exception)
            {

                throw;
            }
        }


        public void Update(Students student)
        {
            try
            {
                _context.Students.Update(student);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
