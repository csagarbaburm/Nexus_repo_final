﻿namespace NexusProjectIntegration.Repositories
{
    public class LoginModule
    {
 
    }
}
