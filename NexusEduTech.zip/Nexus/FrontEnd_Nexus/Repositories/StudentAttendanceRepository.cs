﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using NexusProjectIntegration.Entity;
using NexusProjectIntegration.Models;
using SchoolManagementApi.DTO;
using SchoolManagementApi.DTO_s;
using SchoolManagementApi.Entity;
using System.Diagnostics;

namespace NexusProjectIntegration.Repository
{
    public class StudentAttendanceRepository : IStudentAttendanceRepository
    {
        private readonly MyContext mycontext;
        private readonly IMapper mapper;

        public StudentAttendanceRepository(MyContext context, IMapper mapper)
        {
            mycontext = context;
            this.mapper = mapper;
        }

        public List<StudentAttendanceDto> AddAttendance(DateTime today,string classname)
        {
      
                try
                {

                    List<StudentAttendance> ST = (mycontext.StudentAttendance.Where(s => today == s.Date).ToList());

                    StudentAttendance sts = new StudentAttendance();

                    List<Students> s = mycontext.Students.ToList();

                if (ST.Count() == 0)

                {

                    foreach (Students ss in s)

                    {

                        Random rnd = new Random();

                        sts.StudentId = ss.StudentId;

                        sts.Date = today;

                        sts.AttendanceId = Guid.NewGuid().ToString();
                        sts.Status = "Absent";
                        sts.Classname = (from c in mycontext.Classes
                                        where c.ClassId==ss.ClassId
                                        select c.Name).Single();

                        mycontext.StudentAttendance.Add(sts);

                        mycontext.SaveChanges();

                    }

                    //_context.StudAttendences.Add(sts);

                    //_context.SaveChanges();
                    List<StudentAttendanceDto> stAttlist = mapper.Map<List<StudentAttendanceDto>>(mycontext.StudentAttendance.ToList());



                    return GetAttendanceOfDate(today,classname);
                }
                else
                {
                    //List<StudentAttendanceDto> stAttlist1 = mapper.Map<List<StudentAttendanceDto>>(mycontext.StudentAttendance.ToList());
                    return GetAttendanceOfDate(today,classname);
                }

                }

                catch (Exception ex)

                {

                    throw ex;

                }

            
        }


        public List<StudentAttendanceDto> GetAttendanceOfDate(DateTime today, string classname)
        {
            try
            {

                List<Students> allstds = mycontext.Students.ToList();

                List<StudentAttendanceDto> stAttlist = mapper.Map<List<StudentAttendanceDto>>((mycontext.StudentAttendance.Where(s => today == s.Date && s.Classname == classname).ToList()));

                int i = 0;
                foreach (StudentAttendanceDto st in stAttlist)
                {

                    //st.StudID = allstds[i].StudentId;
                    st.Date = today;
                    st.studentname = (from ss in mycontext.Students
                                      where ss.StudentId == st.StudentId
                                      select ss.FirstName + " " + ss.LastName).SingleOrDefault();
                    st.RollNO = (from ss in mycontext.Students
                                 where ss.StudentId == st.StudentId
                                 select ss.RollNO).SingleOrDefault();

                    i++;
                }

                return stAttlist;
            }
            catch (Exception)
            {

                throw;
            }

        }

        public AttendanceModel GetAllAttendancesByID(string id)
        {
            try
            {
                List<StudentAttendance> studentAttendances = mycontext.StudentAttendance.ToList();

                var attList = (from s in studentAttendances
                               where s.StudentId == id
                               select s).ToList();

                AttendanceModel att = new AttendanceModel();


                float TotalWorkingDays = attList.Count();

                float TotalAttendance = attList.Where(a => a.Status == "Present").Count();

                float AttendancePercentage = (TotalAttendance / TotalWorkingDays) * 100;



                att.TotalAttendance = TotalAttendance.ToString();
                att.TotalWorkingDays = TotalWorkingDays.ToString();
                att.AttendancePercentage = AttendancePercentage.ToString() + '%';

                //List<StudentAttendanceDto> stAttlist= mapper.Map<List<StudentAttendanceDto>>(attList);

                return (att);
            }
            catch (Exception)
            {

                throw;
            }
            
        }
        public StudentAttendanceDto EditAttendance(StudentAttendanceDto attendance)
        {
            try
            {
                StudentAttendance ut = mycontext.StudentAttendance.Where(t => t.StudentId == attendance.StudentId && t.Date == attendance.Date).SingleOrDefault();
                ut.Status = attendance.Status;

                mycontext.StudentAttendance.Update(ut);
                mycontext.SaveChanges();
                return null;
            }
            catch (Exception)
            {

                throw;
            }
        }


        public AttendanceModel GetAttendanceFromDate(string id, DateTime date)
        {
            try
            {
                List<StudentAttendance> studentAttendances = mycontext.StudentAttendance.ToList();

                var attList = (from s in studentAttendances
                               where s.StudentId == id && s.Date.Date >= date.Date
                               select s).ToList();
                AttendanceModel att = new AttendanceModel();
                float TotalWorkingDays = attList.Count();

                float TotalAttendance = attList.Where(a => a.Status == "Present").Count();

                float AttendancePercentage = (TotalAttendance / TotalWorkingDays) * 100;
                att.TotalAttendance = TotalAttendance.ToString();
                att.TotalWorkingDays = TotalWorkingDays.ToString();
                att.AttendancePercentage = AttendancePercentage.ToString() + '%';

                //List<StudentAttendanceDto> stAttlist= mapper.Map<List<StudentAttendanceDto>>(attList);

                return (att);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
