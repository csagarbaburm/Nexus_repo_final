﻿using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repositories
{
    public interface ISubject
    {

        void Add(Subject subject);
        void Update(Subject subject);

        void Delete(string id);
        List<Subject> GetAll();
        Subject Get(string sid);
    }
}

