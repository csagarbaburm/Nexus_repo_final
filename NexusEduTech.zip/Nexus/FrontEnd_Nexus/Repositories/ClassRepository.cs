﻿using Schedule__Class.DTO_s;
using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repositories
{
    public class ClassRepostiory : IClass
    {

        private readonly MyContext _context;

        public ClassRepostiory(MyContext context)
        {
            _context = context;
        }
        public void Add(Classes cls)
        {
            try
            {
                _context.Classes.Add(cls);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }

        }

        public void Delete(string id)
        {
            try
            {

                Classes cls = _context.Classes.Find(id);
                _context.Classes.Remove(cls);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Classes> GetAll()
        {
            try
            {
                return _context.Classes.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Classes GetClassById(string id)
        {
            try
            {
                return _context.Classes.Find(id);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void Update(Classes cls)
        {
            try
            {

                _context.Classes.Update(cls);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}