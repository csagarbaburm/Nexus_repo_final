﻿//using NexusProjectIntegration.DTOs;
using NexusProjectIntegration.DTO_s;
using NexusProjectIntegration.Entity;
using Schedule__Class.DTO_s;

namespace NexusProjectIntegration.Repository
{
    public interface IClassSchedule
    {
        void Add(ClassAdd cls);
        void Update(ClassAdd cls);
        List<ClassDto> GetClassByTeacherID(string teacherId);
        List<ClassTeacherDto> GetClassByClassID(string classId);
        List<ClassDto> GetAll();

        ClassDto GetScheduleById (string id);
    }
}
