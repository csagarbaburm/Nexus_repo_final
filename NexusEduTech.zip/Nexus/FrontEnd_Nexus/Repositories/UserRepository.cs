﻿using Microsoft.EntityFrameworkCore;
using NexusProjectIntegration.Entity.Interface;
using SchoolManagementApi.Entity;
using SMSAPI.Models;


namespace NexusProjectIntegration.Repository
{
    public class UserRepository:IUserRepository
    {
        private readonly MyContext myContext;

        public UserRepository(MyContext myContext)
        {
            this.myContext = myContext;
        }

        public Users AddUser(Users user)
        {
            try
            {
                myContext.Users.Add(user);
                myContext.SaveChanges();
                return (user);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Users EditUser(Users user)
        {
            try
            {
                myContext.Users.Update(user);
                myContext.SaveChanges();
                return (user);
            }
            catch (Exception)
            {

                throw;
            }
        }
        public void DeleteUser(Users user)
        {
            try
            {
                myContext.Users.Add(user);
                myContext.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        public List<Users> GetAll()
        {

            try
            {
                return myContext.Users.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void EditPasword(string username,string password)
        {
            try
            {
                var user = myContext.Users.FirstOrDefault(u => u.UserName == username);
                user.EnPassword = password;
                myContext.Update(user);
                myContext.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Users GetUser(string username)
        {
            try
            {
                return myContext.Users.SingleOrDefault(e => e.UserName == username);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Users Validate(LoginUser loginUser)
        {
            try
            {
                return myContext.Users.SingleOrDefault(u => u.UserName == loginUser.UserName && u.EnPassword == loginUser.Password);
            }
            catch (Exception)
            {

                throw;
            }
        }
        public bool Verify(string email,string mobile)
        {
            try
            {
                var t = (from u in myContext.Users
                         where u.Email == email && u.MobileNum == mobile
                         select u).SingleOrDefault();

                if (t == null) return false;
                else return true;
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
