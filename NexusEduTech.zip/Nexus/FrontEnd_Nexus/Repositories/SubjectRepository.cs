﻿using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repositories
{
    public class SubjectRepository : ISubject
    {
        private readonly MyContext context;

        public SubjectRepository(MyContext context)
        {
            this.context = context;
        }
        public void Add(Subject subject)
        {
            try
            {
                context.Subjects.Add(subject);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void Delete(string id)
        {
            try
            {
                Subject subject = context.Subjects.Find(id);
                context.Subjects.Remove(subject);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Subject Get(string sid)
        {
            try
            {
                return context.Subjects.Find(sid);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Subject> GetAll()
        {
            try
            {
                return context.Subjects.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void Update(Subject subject)
        {
            try
            {
                context.Subjects.Update(subject);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}