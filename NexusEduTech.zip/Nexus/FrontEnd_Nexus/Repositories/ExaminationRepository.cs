﻿using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repository
{
    public class ExaminationRepository : IExamination
    {
        private readonly MyContext _context;

        public ExaminationRepository(MyContext context)
        {
            _context = context; 
        }
        public void Add(Examinations examinations)
        {
            try
            {
                _context.Examinations.Add(examinations);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
          
        }

        public void Delete(string eId)
        {
            try
            {
                Examinations exam = _context.Examinations.Find(eId);
                _context.Examinations.Remove(exam);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Examinations> GetAll()
        {
            try
            {
                return _context.Examinations.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Examinations GetExamById(string eId)
        {
            try
            {

                Examinations exam = _context.Examinations.Find(eId);
                return exam;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void Update(Examinations examinations)
        {
            try
            {
                _context.Examinations.Update(examinations);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
