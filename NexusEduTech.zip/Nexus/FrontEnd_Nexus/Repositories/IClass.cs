﻿using Schedule__Class.DTO_s;
using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repositories
{
    public interface IClass
    {

        void Add(Classes cls);
        void Update(Classes cls);
        void Delete(string id);
        List<Classes> GetAll();

        Classes GetClassById(string id);
    }
}