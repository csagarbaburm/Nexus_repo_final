﻿using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repositories
{
    public class PasswordRecovey:IPasswordRecovery
    {
        private readonly MyContext myContext;

        public PasswordRecovey(MyContext myContext)
        {
            this.myContext = myContext;
        }

        public void Recovey(string username,string password)
        {
            try
            {
                Users users = myContext.Users.Single(u => u.UserName == username);
                users.EnPassword = password;
                myContext.Update(users);
                myContext.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }   
        }
        public string Verify(string email, string mobile)
        {
            try
            {
                Users users = myContext.Users.SingleOrDefault(u => u.Email == email && u.MobileNum == mobile);

                return users.UserName;
            }
            catch (Exception)
            {

                throw;
            }


        }



    }
}
