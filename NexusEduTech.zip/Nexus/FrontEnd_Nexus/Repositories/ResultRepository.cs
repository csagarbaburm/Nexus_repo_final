﻿

//using SchoolManagementApi.Entity;

using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repositories
{
    public class ResultRepository : IResult
    {
        private readonly MyContext _context;

        public ResultRepository(MyContext context)
        {
            _context = context;
        }

        public void AddResult(StdResult result)
        {
            try
            {
                _context.stdResults.Add(result);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
           
        }



        public void DeleteResult(string id)
        {
            StdResult result = _context.stdResults.Find(id);
            _context .stdResults.Remove(result);
            _context.SaveChanges();
        }


        public List<StdResult> GetByStudentId(string id)
        {
            try
            {
                return (_context.stdResults.Where(r=>r.StuId==id)).ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<StdResult> GetByStudentIdandexam(string id,string exam)
        {
            try
            {
                return (_context.stdResults.Where(r => r.StuId == id  && r.ExamName == exam)).ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }
        


        public void UpdateResult(StdResult result)
        {
            throw new NotImplementedException();
        }

        public List<StdResult> AllResults()
        {
            try
            {
                return _context.stdResults.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public StdResult GetById(string id)
        {
            try
            {
                return _context.stdResults.Find(id);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
