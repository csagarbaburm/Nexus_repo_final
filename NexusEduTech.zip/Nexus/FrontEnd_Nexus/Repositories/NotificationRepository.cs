﻿

using NexusProjectIntegration.Entity;
using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Repository
{
    public class NotificationRepository : INotificationRepository<NotificationEntity>
    {
        private readonly MyContext _context;

        public NotificationRepository(MyContext context)
        {
            _context = context;
        }
        public void Add(NotificationEntity entity)
        {
            entity.NotificationId = new Random().Next(1000, 10000);
            _context.notificationEntities.Add(entity);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            NotificationEntity notification = _context.notificationEntities.Find(id);
            _context.notificationEntities.Remove(notification);
            _context.SaveChanges();
        }

        public NotificationEntity Get(int id)
        {
            return _context.notificationEntities.Find(id);
        }

        public List<NotificationEntity> GetAll()
        {
            return _context.notificationEntities.ToList();
        }

        public void Update(NotificationEntity entity)
        {
            _context.notificationEntities.Update(entity);
        }
    }
}
