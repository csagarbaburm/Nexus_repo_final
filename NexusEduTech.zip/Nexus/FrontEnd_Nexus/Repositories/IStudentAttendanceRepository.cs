﻿using NexusProjectIntegration.Models;
using SchoolManagementApi.DTO;

namespace NexusProjectIntegration.Repository
{
    public interface IStudentAttendanceRepository
    {
        List<StudentAttendanceDto> AddAttendance(DateTime date,string classname);
        AttendanceModel GetAllAttendancesByID(string id);
        AttendanceModel GetAttendanceFromDate(string id,DateTime date);
        StudentAttendanceDto EditAttendance(StudentAttendanceDto attendance);

    }
}
