﻿using System.ComponentModel.DataAnnotations;

namespace SchoolManagementApi.DTOs
{
    public class ResultDto
    {
        public string MarksId { get; set; }

        public string ExamName { get; set; }
    
        public string StuId { get; set; }
       
        public string ClssId { get; set; }
      
        public string SubId { get; set; }
       
        public int Mark { get; set; }
  
    
    }
}
