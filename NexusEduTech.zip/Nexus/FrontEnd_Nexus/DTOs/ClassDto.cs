﻿namespace Schedule__Class.DTO_s
{
    public class ClassDto
    {
        public string ScheduleId { get; set; }
        public string SessionTime { get; set; }
        public string ClassName{ get; set; }
        public string TeachName { get; set; }
        public string SubName { get; set; }
    }
}
