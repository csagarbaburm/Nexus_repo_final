﻿namespace Schedule__Class.DTO_s
{
    public class ClassTeacherDto
    {

        public string SessionTime { get; set; }
        public string TeachName { get; set; }
        public string SubName { get; set; }
    }
}
