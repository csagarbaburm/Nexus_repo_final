﻿namespace SchoolManagementApi.DTO
{
    public class TeacherAttendanceDto
    {
        public string TeacherId {  get; set; }
        public string TeacherName {  get; set; }
        public DateTime Date { get; set; }
        public string Status { get; set; }
    }
}
