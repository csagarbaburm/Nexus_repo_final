﻿namespace SchoolManagementApi.DTO
{
    public class StudentAttendanceDto
    {
        public string StudentId {  get; set; }
        public string studentname {  get; set; }

        public string RollNO { get; set; }
        public DateTime Date { get; set; }
        public string Status { get; set; }
        public string Classname { get; set; }

    }
}
