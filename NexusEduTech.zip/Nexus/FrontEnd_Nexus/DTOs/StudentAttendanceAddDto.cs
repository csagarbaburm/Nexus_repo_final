﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SchoolManagementApi.DTO
{
    public class StudentAttendanceAddDto
    {
        public string AttendanceId { get; set; }
   
        public string StudentId { get; set; }

     
        public DateTime Date { get; set; }
      
        public string Status { get; set; }
    }
}
