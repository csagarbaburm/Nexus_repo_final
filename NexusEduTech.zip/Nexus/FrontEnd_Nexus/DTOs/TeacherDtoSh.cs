﻿namespace NexusProjectIntegration.DTO_s
{
    public class TeacherDto
    {
        public string SessionTime { get; set; }
        public string ClassName { get; set; }
        public string SubName { get; set; }
    }
}
