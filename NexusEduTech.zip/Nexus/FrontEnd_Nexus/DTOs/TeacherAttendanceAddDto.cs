﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SchoolManagementApi.DTO
{
    public class TeacherAttendanceAddDto
    {
        public string AttendanceId { get; set; }

        public string TeacherId { get; set; }



        public DateTime Date { get; set; }


        public string Status { get; set; }
    }
}
