﻿using System.ComponentModel.DataAnnotations;

namespace Schedule__Class.DTO_s
{
    public class ClassAdd
    {
        public string ScheduleId { get; set; }

        public string ClassId { get; set; }
      
        public string SessionTime { get; set; }
        
        public string TeacId { get; set; }
        
        public string SubjId { get; set; }
    }
}
