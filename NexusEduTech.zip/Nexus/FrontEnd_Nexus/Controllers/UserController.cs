﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NexusProjectIntegration.Repository;
using SchoolManagementApi.Entity;


namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]



    public class UserController : ControllerBase
    {
        private readonly UserRepository userRepository;

        public UserController(UserRepository userRepository)
        {
            this.userRepository = userRepository;
        }
        [HttpPost("ADDUser")]
        [AllowAnonymous]
        public IActionResult AddUser(Users user)
        {
            try
            {
                userRepository.AddUser(user);
                return Ok(user);
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet("GetAllUsers")]
        [AllowAnonymous]
        public IActionResult GetAllUsers()
        {

            try
            {
                return Ok(userRepository.GetAll());
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpPost("GetUserbyUsername/{username}")]
        [AllowAnonymous]
        public IActionResult GetUserByUsername(string username)
        {

            try
            {
                return Ok(userRepository.GetUser(username));
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpPost("EditUSer")]
        [AllowAnonymous]
        public IActionResult EditUser(Users user)
        {
            try
            {
                userRepository.EditUser(user);
                return Ok(user);
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpPut("EditPassword/{username}/{password}")]
        [AllowAnonymous]
        public IActionResult EditUser(string username,string password) {

            try
            {
                userRepository.EditPasword(username, password);
                return Ok("Password changed successfully");
            }
            catch (Exception)
            {

                throw;
            }
                
        }
        [HttpPost("VerifyUserPasswordRecovery/{email}/{mobile}")]
        [AllowAnonymous]
        public IActionResult verifyUser(string email,string mobile) 
        {

            try
            {
                return Ok(userRepository.Verify(email, mobile));
            }
            catch (Exception)
            {

                throw;
            }
        
        }
    }
}
