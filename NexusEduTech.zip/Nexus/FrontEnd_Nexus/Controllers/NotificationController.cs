﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NexusProjectIntegration.Entity;
using NexusProjectIntegration.Repository;


namespace NexusProjectIntegration.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationController : ControllerBase
    {
        private readonly NotificationRepository notificationRepository;

        public NotificationController(NotificationRepository notificationRepository)
        {
            this.notificationRepository = notificationRepository;
        }

        [HttpPost, Route("AddNotification")]
        [Authorize(Roles ="Admin")]
        public IActionResult Add([FromBody] NotificationEntity notification)
        {
            notificationRepository.Add(notification);
            return Ok(notification);
        }
        [HttpPut, Route("EditNotification")]
        [Authorize(Roles = "Admin")]
        public IActionResult Update([FromBody] NotificationEntity notification)
        {
            notificationRepository.Update(notification);
            return Ok(notification);
        }
        [HttpGet, Route("GetNotification")]
        [Authorize(Roles = "Teacher,Admin,Student")]
        public IActionResult GetAll()
        {
            return Ok(notificationRepository.GetAll());
        }
        [HttpDelete, Route("DeleteNotification/{id}")]
        [Authorize(Roles = "Admin")]
        
        public IActionResult Delete(int id)
        {
            try
            {
                notificationRepository.Delete(id);
                return Ok("Notification Deleted");
            }
            catch (Exception)
            {
                throw;
            }
        }
      
    }
}
