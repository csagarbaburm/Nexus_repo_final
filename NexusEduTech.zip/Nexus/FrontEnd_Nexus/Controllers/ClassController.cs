﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NexusProjectIntegration.Repositories;
using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ClassController : ControllerBase
    {

        private readonly ClassRepostiory classRepostiory;
        public ClassController(ClassRepostiory classRepostiory)
        {
            this.classRepostiory = classRepostiory;
        }

        [HttpGet, Route("GetAllClass")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult GetClassAll()
        {
            try
            {
                List<Classes> cls = classRepostiory.GetAll();
                if (cls == null || !cls.Any())
                {
                    return NotFound("No books found."); // Return 404 status code with error message
                }

                return Ok(cls); // Return 200 status code with the list of 
            }
            catch (Exception ex)
            {
                // Log the exception for further investigation
                // logger.LogError(ex, "An error occurred while retrieving .");

                return StatusCode(500, "An error occurred while processing your request."); // Return 500 status code with error message
            }
        }

        [HttpDelete, Route("DeleteClass/{id}")]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteClass(string id)
        {
            try
            {
                classRepostiory.Delete(id);
                return Ok("Class Deleted"); // Return 200 status code with success message
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while processing your request."); // Return 500 status code with error message
            }

        }
        [HttpGet, Route("GetClassById")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult GetClassById(string id)
        {
            try
            {
                Classes cls = classRepostiory.GetClassById(id);
                if (cls == null)
                {
                    return NotFound($"Student  with  id{id} is not found");
                }

                return Ok(cls);

            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while processing your request."); // Return 500 status code with error message
            }
        }
        [HttpPost, Route("AddClass")]
        [Authorize(Roles = "Admin")]
        public IActionResult AddClass([FromBody] Classes cls)
        {
            try
            {
                classRepostiory.Add(cls);
                return Ok(cls); // Return 200 status code with the added book object
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while processing your request."); // Return 500 status code with error message
            }
        }
        [HttpPut, Route("EditClass")]
        [Authorize(Roles = "Admin")]
        public IActionResult EditClass([FromBody] Classes cls)
        {
            try
            {
                classRepostiory.Update(cls);
                return Ok(cls); // Return 200 status code with the updated book object
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while processing your request."); // Return 500 status code with error message
            }
        }
    }
}