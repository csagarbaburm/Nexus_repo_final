﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NexusProjectIntegration.Repositories;
using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubjectController : ControllerBase
    {

        private readonly SubjectRepository subjectRepository;

        public SubjectController(SubjectRepository subjectRepository)
        {
            this.subjectRepository = subjectRepository;
        }

        [HttpGet, Route("GetAllSubjects")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult GetAll()
        {
            try
            {
                List<Subject> subjects = subjectRepository.GetAll();
                return Ok(subjects);
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet, Route("GetByID")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult Get(string sid)
        {
            try
            {
                Subject subject = subjectRepository.Get(sid);
                return Ok(subject);
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpDelete, Route("Delete Subject/{id}")]
        [Authorize(Roles = "Admin")]
        public IActionResult Delete(string id)
        {
            try
            {
                subjectRepository.Delete(id);
                return Ok("Subject Deleted!");
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpPost, Route("Add subject")]
        [Authorize(Roles = "Admin")]
        public IActionResult Add([FromBody] Subject subject)
        {
            try
            {
                subjectRepository.Add(subject);
                return Ok(subject);
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpPut, Route("EditSubject")]
        [Authorize(Roles = "Admin")]
        public IActionResult Edit([FromBody] Subject subject)
        {
            try
            {
                subjectRepository.Update(subject);
                return Ok(subject);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}

