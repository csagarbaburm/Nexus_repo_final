﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NexusProjectIntegration.Repositories;

namespace NexusProjectIntegration.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentRegistryController : ControllerBase
    {
        private readonly StudentRegisterRepository studentRegisterRepository;

        public StudentRegistryController(StudentRegisterRepository studentRegisterRepository)
        {
            this.studentRegisterRepository = studentRegisterRepository;
        }


        [HttpGet("GetAll")]
        [AllowAnonymous]
        public IActionResult Get()
        {
            try
            {
                return Ok(studentRegisterRepository.GetAll());
            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }
        [HttpGet("GetById/{id}")]
        [AllowAnonymous]
        public IActionResult GetByID(string id)
        {
            try
            {
                var st= studentRegisterRepository.GetById(id);

                    return Ok(st);

            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }


    }
}
