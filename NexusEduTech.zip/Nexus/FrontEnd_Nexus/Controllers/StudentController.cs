﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using NexusProjectIntegration.Repository;
using SchoolManagementApi.DTO_s;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private static List<Students> students = new List<Students>();
        private readonly IMapper _mapper;
        private readonly StudentRepository studentRepository;

        public StudentController(IMapper mapper, StudentRepository studentRepository)
        {
            this._mapper = mapper;
            this.studentRepository = studentRepository;
        }


        [HttpGet, Route("GetAllStudent")]
        [Authorize(Roles = "Admin,Teacher")]
        public IActionResult StudentAll()
        {
            try
            {

                return Ok(studentRepository.GetAll());
            }
            catch (Exception ex)
            {

                return StatusCode(500, "An error occurred while processing your request.");
            }
        }

        [HttpGet, Route("GetStudentRoll/{roll}")]
        [Authorize(Roles ="Admin,Teacher,Student")]
        public IActionResult GetByRoll(string roll)
        {
            try
            {
                StudentDto student = studentRepository.GetStudentByRoll(roll);
                if (student == null)
                {
                    return NotFound($"student withe roll number{roll} is not found");
                }

                return Ok(student);

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message); 
            }
        }

        [HttpGet, Route("GetStudentClass/{cls}")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult GetByClass(String cls)
        {
            try
            {
                List<StudentDto> students = studentRepository.GetStudentByClass(cls);
                if (students == null)
                {
                    return NotFound($"Student with class{cls} is not found");
                }

                return Ok(students);

            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }
        [HttpGet, Route("GetStudentClass/{cls}/{sec}")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult GetByClassandSec(String cls,string sec)
        {
            try
            {
                List<StudentDto> students = studentRepository.GetStudentByClassandSec(cls,sec);
                if (students == null)
                {
                    return NotFound($"Student with class{cls} is not found");
                }

                return Ok(students);

            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }

        [HttpPost, Route("AddStudent")]
        [AllowAnonymous]
        public IActionResult Add([FromBody] StudentAddDto studentdto)
        {
            try
            {
                Students student = _mapper.Map<Students>(studentdto);
                if (ModelState.IsValid)
                {
                    studentRepository.Add(student);
                    return Ok(student);
                }
                return new JsonResult("Something went wrong here")
                { StatusCode = 500 };
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut,Route("EditStudent")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult Update([FromBody] StudentAddDto studentdto)
        {
            try
            {
                Students student = _mapper.Map<Students>(studentdto);
                if(ModelState.IsValid)
                {
                    studentRepository.Update(student);
                    return Ok(student);
                }
                return new JsonResult("Something went wrong")
                { StatusCode = 500 };
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpDelete, Route("DeleteStudent/{id}")]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteStudent(string id)
        {
            try
            {
                studentRepository.Delete(id);
                return Ok("Success"); 
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message); 
            }
        }

        [HttpGet, Route("GetStudentId/{id}")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult GetStudentById(string id)
        {
            try
            {
                StudentDto student = studentRepository.GetStudentById(id);
                if (student == null)
                {
                    return NotFound($"student withe roll number{id} is not found");
                }

                return Ok(student);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while processing your request.");
            }
        }

    }
}
