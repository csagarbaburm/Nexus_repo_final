﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NexusProjectIntegration.Repositories;
using SchoolManagementApi.DTOs;
using SchoolManagementApi.Entity;

using static System.Runtime.InteropServices.JavaScript.JSType;

namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class TeacherController : ControllerBase
    {
        private readonly TeacherRepository teacherrepository;

        private readonly IMapper mapper;
        private readonly MyContext context;

        public TeacherController(TeacherRepository teacherrepository, IMapper mapper, MyContext context)
        {
            this.teacherrepository = teacherrepository;
            this.mapper = mapper;
            this.context = context;
        }

        [HttpGet, Route("GetAllTeachers")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult GetTeachers()
        {
            try
            {
                List<Teachers> t1 = teacherrepository.GetTeachers().ToList();
                List<TeacherDTO> Getall = mapper.Map<List<TeacherDTO>>(t1);

                int i = 0;

                foreach (TeacherDTO t in Getall)
                {
                    t.SubjectTaught = (from s in context.Subjects
                                       where s.SubId == t1[i].SubjId
                                       select s.SubName).Single();
                    i++;
                }



                return Ok(Getall);
            }
            catch (Exception)
            {

                throw;
            }
        }



        [HttpGet, Route("GetTeacher/{id}")]
        [Authorize(Roles = "Admin,Teacher,Student")]

        public IActionResult GetById(string id)
        {
            try
            {
                Teachers t1 = teacherrepository.GetBYid(id);
                TeacherDTO teacherDTO = mapper.Map<TeacherDTO>(t1);


                teacherDTO.SubjectTaught = (from s in context.Subjects
                                            where s.SubId == t1.SubjId
                                            select s.SubName).SingleOrDefault();

                return Ok(teacherDTO);
            }
            catch (Exception)
            {

                throw;
            }
        }



        //Post actions
        [HttpPost, Route("AddTeacher")]
        [AllowAnonymous]
        public IActionResult AddTeacher([FromBody] TeacherDToadd teacher)
        {
            try
            {
                Teachers teacherdto = mapper.Map<Teachers>(teacher);
                if (ModelState.IsValid)
                {



                    teacherrepository.AddTeacher(teacherdto);
                    return Ok(teacherdto);
                }

                return new JsonResult("Something went wrong") { StatusCode = 500 };
            }
            catch (Exception)
            {

                throw;
            }
        }



        //Put actions
        [HttpPut, Route("EditTeacher")]
        [Authorize(Roles = "Admin,Teacher")]
        public IActionResult Update([FromBody] TeacherDToadd teacher)
        {
            try
            {
                Teachers teacherdto = mapper.Map<Teachers>(teacher);
                if (ModelState.IsValid)
                {
                    teacherrepository.EditTeacher(teacherdto);
                    return Ok(teacherdto);
                }
                return new JsonResult("Something went wrong") { StatusCode = 500 };
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Delete actions
        [HttpDelete, Route("DeleteTeacher/{id}")]
        [Authorize(Roles = "Admin")]
        public IActionResult Delete(string id)
        {
            try
            {
                teacherrepository.DeleteTeacher(id);
                return Ok("Student Deleted");
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpGet, Route("GetTeacherbsubject/{subject}")]
        [Authorize(Roles = "Admin")]
        public IActionResult GetBysubject(string subject)
        {
            try
            {

                List<Teachers> t1 = teacherrepository.GetBysubject(subject).ToList();
                List<TeacherDTO> GetBYsubjects = mapper.Map<List<TeacherDTO>>(t1);
                int i = 0;

                foreach (TeacherDTO t in GetBYsubjects)
                {
                    t.SubjectTaught = (from s in context.Subjects
                                       where s.SubId == t1[i].SubjId
                                       select s.SubName).Single();
                    i++;
                }
                return Ok(GetBYsubjects);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
