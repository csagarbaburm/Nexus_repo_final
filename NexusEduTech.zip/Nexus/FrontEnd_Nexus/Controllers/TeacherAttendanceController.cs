﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NexusProjectIntegration.Repository;
using SchoolManagementApi.DTO;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherAttendanceController : ControllerBase
    {
        private readonly TeacherAttendanceRepository teacherAttendanceRepository;

        public TeacherAttendanceController(TeacherAttendanceRepository teacherAttendanceRepository)
        {
            this.teacherAttendanceRepository = teacherAttendanceRepository;

        }

        [HttpPost("AddTeacherAttendance/{today}")]
        [AllowAnonymous]
        public IActionResult AddteacherAttend(DateTime today)
        {
            try
            {
               
                if (ModelState.IsValid && today<=DateTime.Today)
                {

                    return Ok(teacherAttendanceRepository.AddAttendance(today));
                }

                return new JsonResult("Can update only attendance till date") { StatusCode = 500 };
            }
            catch (Exception)
            {

                throw;
            }
        }
      
        [HttpPut("EditAttendance")]
        [Authorize(Roles = "Admin")]
        public IActionResult EditAttendance(TeacherAttendanceDto teacherAttendance)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    teacherAttendanceRepository.EditAttendance(teacherAttendance);

                    return Ok(teacherAttendance);
                }

                return new JsonResult("Something went wrong") { StatusCode = 500 };
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet("GetAttendReportof/{id}")]
        [Authorize(Roles = "Admin,Teacher")]
        public IActionResult getAttendanceReport(string id)
        {
            try
            {

                return Ok(teacherAttendanceRepository.GetAllAttendancesByID(id));
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet("GetAttendReportof/{id}/{date}")]
        [Authorize(Roles = "Admin,Teacher")]
        public IActionResult getAttendanceReport(string id, DateTime date)
        {
            try
            {
                return Ok(teacherAttendanceRepository.GetAttendanceFromDate(id, date));
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
