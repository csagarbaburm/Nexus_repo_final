﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NexusProjectIntegration.Repository;
using SchoolManagementApi.DTO;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentAttendanceController : ControllerBase
    {
        private readonly StudentAttendanceRepository studentAttendanceRepository;


        public StudentAttendanceController(StudentAttendanceRepository studentAttendanceRepository)
        {
            this.studentAttendanceRepository = studentAttendanceRepository;

        }

        [HttpPost("AddStudentAttendance/{today}/{classname}")]
        [Authorize(Roles ="Teacher")]

        public IActionResult AddStAttendace(DateTime today,string classname)
        {
            try
            {
                if (ModelState.IsValid && today<=DateTime.Today)
                {
                    //studentAttendanceRepository.AddAttendance(today);

                    return Ok(studentAttendanceRepository.AddAttendance(today,classname));
                }

                return new JsonResult("Can add attendance only till date") { StatusCode = 500 };
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpPut("EditAttendance")]
        [Authorize(Roles = "Teacher")]
        public IActionResult EditAttendance(StudentAttendanceDto editAttendance)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    studentAttendanceRepository.EditAttendance(editAttendance);

                    return Ok(editAttendance);
                }

                return new JsonResult("Something went wrong") { StatusCode = 500 };
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet("GetAttendReportof/{id}")]
        [AllowAnonymous]
        public IActionResult getAttendanceReport(string id)
        {
            try
            {

                return Ok(studentAttendanceRepository.GetAllAttendancesByID(id));

            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet("GetAttendReportof/{id}/{date}")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult getAttendanceReport(string id,DateTime date)
        {
            try
            {
                return Ok(studentAttendanceRepository.GetAttendanceFromDate(id, date));
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
