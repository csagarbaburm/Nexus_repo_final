﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NexusProjectIntegration.Repositories;

namespace NexusProjectIntegration.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherRegistryController : ControllerBase
    {
        private readonly TeacherRegisterRepository teacherRegisterRepository;

        public TeacherRegistryController(TeacherRegisterRepository teacherRegisterRepository)
        {
            this.teacherRegisterRepository = teacherRegisterRepository;
        }


        [HttpGet("GetAll")]
        [AllowAnonymous]
        public IActionResult Get()
        {
            try
            {
                return Ok(teacherRegisterRepository.GetAll());
            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }
        [HttpGet("GetById/{id}")]
        [AllowAnonymous]
        public IActionResult GetByID(string id)
        {
            try
            {
                var st = teacherRegisterRepository.GetById(id);

                return Ok(st);

            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
    }
}
