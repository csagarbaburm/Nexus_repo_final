﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
//using NexusProjectIntegration.DTOs;
using NexusProjectIntegration.Entity;
using NexusProjectIntegration.Repositories;
using NexusProjectIntegration.Repository;
using Schedule__Class.DTO_s;

namespace NexusProjectIntegration.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScheduleClassController : ControllerBase
    {
        private readonly ClassScheduleRepo classRepository;
        private readonly IMapper _mapper;
        public ScheduleClassController(ClassScheduleRepo classRepository)
        {
            this.classRepository = classRepository;
        }

        [HttpGet, Route("GetAll")]
        [Authorize(Roles = "Admin,Teacher,Student")]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(classRepository.GetAll());
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpPost, Route("AddSchedule")]
        [Authorize(Roles = "Admin")]
        public IActionResult Add([FromBody] ClassAdd sclass)
        {
            try
            {
                classRepository.Add(sclass);
                return Ok(sclass);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet, Route("GetClassByClassId/{classId}")]
        [Authorize(Roles = "Admin")]
        public IActionResult GetClassByClassID(string classId)
        {
            try
            {
                return Ok(classRepository.GetClassByClassID(classId));
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet, Route("GetClassByTeacherId/{teacherId}")]
        [Authorize(Roles = "Admin,Teacher")]
        public IActionResult GetClassByTeacherID(string teacherId)
        {
            try
            {
                return Ok(classRepository.GetClassByTeacherID(teacherId));
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpPut, Route("Update")]
        [Authorize(Roles = "Admin")]
        public IActionResult Update(ClassAdd cls)
        {
            try
            {
                classRepository.Update(cls);
                return Ok(cls);
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpGet, Route("GetScheduleById/{scheduleId}" )]
        [Authorize(Roles = "Admin")]

        public IActionResult GetScheduleById(string scheduleId)
        {
            try
            {
                return Ok(classRepository.GetScheduleById(scheduleId));
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
