﻿namespace SMSAPI.Models
{
    public class AuthReponse
    {
        public string UserName { get; set; }
        public string Role { get; set; }
        public string Token { get; set; }
    }
}
