﻿namespace NexusProjectIntegration.Models
{
    public class AttendanceModel
    {
        public string TotalWorkingDays {  get; set; }
        public string TotalAttendance { get; set;}
        public string AttendancePercentage { get; set;}
    }
}
