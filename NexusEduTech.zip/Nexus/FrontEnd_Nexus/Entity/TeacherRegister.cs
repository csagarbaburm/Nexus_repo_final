﻿using System.ComponentModel.DataAnnotations;

namespace NexusProjectIntegration.Entity
{
    public class TeacherRegister
    {
        [Key]
        public string TchrRegId {  get; set; }
    }
}
