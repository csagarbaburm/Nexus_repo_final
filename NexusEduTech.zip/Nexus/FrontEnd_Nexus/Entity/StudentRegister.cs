﻿using System.ComponentModel.DataAnnotations;

namespace NexusProjectIntegration.Entity
{
    public class StudentRegister
    {
        [Key]
        public string StRegId { get; set; }
    }
}
