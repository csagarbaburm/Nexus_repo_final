﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
namespace NexusProjectIntegration.Entity { 
    public class NotificationEntity
    {
        [Key] 
        [DatabaseGenerated(DatabaseGeneratedOption.None)] 
        public int NotificationId { get; set; }
        [Required]
        [StringLength(50)]
        public string? Message { get; set; }
        [Required]
    
        public DateTime Date { get; set; }
        [Required]
        [StringLength(50)]
        public string? Role { get; set; }
    }
}
