﻿using SchoolManagementApi.Entity;

namespace NexusProjectIntegration.Entity.Interface
{
    public interface IUserRepository
    {
        List<Users> GetAll();
        void DeleteUser(Users user);
        Users EditUser(Users user);
        Users AddUser(Users user);
        Users GetUser(string username);
    }
}
