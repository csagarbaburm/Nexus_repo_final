﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SchoolManagementApi.Entity
{
    public class StdResult
    {
        [Key]
        public string MarksId { get; set; }
        [Required]
        public string ExamName { get; set; }
        [Required]
        public string StuId { get; set; }
        [Required]
        public string ClssId { get; set; }
        [Required]
        public string SubId { get; set; }
        [Required]
        public int Mark { get; set; }
        [Required]
        public string result { get; set; } = "Fail";
        [Required]


        [ForeignKey("StuId")]
        public Students? Students { get; set; }
        [ForeignKey("ClssId")]
        public Classes? Classes { get; set; }

        [ForeignKey("SubId")]
        public Subject? subjects { get; set; }
    }
}
