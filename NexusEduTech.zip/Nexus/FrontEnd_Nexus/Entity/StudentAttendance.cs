﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SchoolManagementApi.Entity
{
    public class StudentAttendance
    {
        [Key]
        public string AttendanceId { get; set; }
        [Required]
        [Column("StudID")]
        public string StudentId { get; set; }
        [Required]

        public DateTime Date { get; set; }
        [Required]

        public string Classname { get; set; }
        [Required]
        public string Status { get; set; }

        [ForeignKey("StudentId")]
        public Students? students { get; set; }
    }
}
